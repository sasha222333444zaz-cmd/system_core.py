package com.example.model

import androidx.compose.ui.graphics.Color
import kotlin.math.*

data class Vector2(val x: Float = 0f, val y: Float = 0f) {
    operator fun plus(other: Vector2) = Vector2(x + other.x, y + other.y)
    operator fun minus(other: Vector2) = Vector2(x - other.x, y - other.y)
    operator fun times(scalar: Float) = Vector2(x * scalar, y * scalar)
    operator fun div(scalar: Float) = if (scalar != 0f) Vector2(x / scalar, y / scalar) else Vector2(0f, 0f)

    fun length(): Float = sqrt(x * x + y * y)
    fun lengthSquared(): Float = x * x + y * y

    fun normalized(): Vector2 {
        val len = length()
        return if (len > 0.0001f) Vector2(x / len, y / len) else Vector2(0f, 0f)
    }

    fun distanceTo(other: Vector2): Float = (this - other).length()

    fun angleRad(): Float = atan2(y, x)
    fun angleDeg(): Float = (angleRad() * 180f / PI.toFloat() + 360f) % 360f

    companion object {
        val Zero = Vector2(0f, 0f)
        val Up = Vector2(0f, -1f)
        val Down = Vector2(0f, 1f)
        val Left = Vector2(-1f, 0f)
        val Right = Vector2(1f, 0f)

        fun fromAngle(angleRad: Float): Vector2 = Vector2(cos(angleRad), sin(angleRad))
    }
}

enum class WeaponType(
    val displayName: String,
    val description: String,
    val damage: Float,
    val cooldown: Float
) {
    BASEBALL_BAT(
        displayName = "Ясеневий бейсбольний кий",
        description = "Міцна дерев'яна бита з багажника авто. Швидкі удари з потужним відкиданням.",
        damage = 45f,
        cooldown = 0.42f
    ),
    REVOLVER(
        displayName = "Поліцейський револьвер .38",
        description = "Знайдений у бардачку авто. Висока вбивча сила. Набоїв обмаль.",
        damage = 85f,
        cooldown = 0.55f
    )
}

enum class MonsterCategory {
    MIST_WEEPER,
    BRAMBLE_CRAWLER,
    GORGE_ECHO_BOSS,
    TIMBER_LURKER,
    LANTERN_GHOUL,
    CORRUPTED_WOODCUTTER_BOSS,
    STATIC_PHANTOM,
    GUILT_WEAVER,
    THE_VOID_BOSS
}

enum class MonsterState {
    IDLE,
    CHASE,
    ATTACKING,
    STUNNED,
    DEAD
}

data class Monster(
    val id: String,
    val category: MonsterCategory,
    val name: String,
    var pos: Vector2,
    var velocity: Vector2 = Vector2.Zero,
    var hp: Float,
    val maxHp: Float,
    val speed: Float,
    val touchDamage: Float,
    val attackRange: Float,
    val aggroRadius: Float,
    var state: MonsterState = MonsterState.IDLE,
    var stunTimer: Float = 0f,
    var attackCooldownTimer: Float = 0f,
    var facingAngle: Float = 0f,
    var animTimer: Float = 0f,
    var customPhase: Int = 0,
    var specialAttackTimer: Float = 0f
) {
    val isBoss: Boolean
        get() = category == MonsterCategory.GORGE_ECHO_BOSS ||
                category == MonsterCategory.CORRUPTED_WOODCUTTER_BOSS ||
                category == MonsterCategory.THE_VOID_BOSS
}

data class Projectile(
    val id: Long,
    var pos: Vector2,
    val velocity: Vector2,
    val damage: Float,
    var lifeTimer: Float,
    val maxLife: Float = 1.5f,
    val isPlayerBullet: Boolean = true,
    val radius: Float = 4f,
    val color: Color = Color(0xFFFFD54F)
)

data class Particle(
    var pos: Vector2,
    var velocity: Vector2,
    val color: Color,
    val size: Float,
    var life: Float,
    val maxLife: Float
)

data class FloatingCombatText(
    val text: String,
    var pos: Vector2,
    val color: Color,
    var life: Float = 1.0f,
    val maxLife: Float = 1.0f
)

enum class InteractableType {
    CAR_GLOVEBOX,
    CAR_TRUNK,
    CAR_DOOR,
    NOTE,
    AMMO_PICKUP,
    MEDKIT_PICKUP,
    SANITY_MEDS,
    KEY_ITEM,
    DOOR_PORTAL,
    GENERATOR_SWITCH,
    WOODCUTTER_CHEST,
    CRAG_DESCENT_LEDGE,
    VOID_PORTAL,
    SAVE_LANTERN
}

data class Interactable(
    val id: String,
    val pos: Vector2,
    val radius: Float = 48f,
    val type: InteractableType,
    val name: String,
    val prompt: String,
    val description: String = "",
    var isTriggered: Boolean = false,
    var isCollected: Boolean = false,
    val requiredKeyId: String? = null
)

data class InventoryItem(
    val id: String,
    val name: String,
    val description: String,
    var count: Int = 1,
    val category: ItemCategory,
    val isConsumable: Boolean = false
)

enum class ItemCategory {
    WEAPON,
    AMMO,
    MEDICAL,
    KEY,
    LORE
}

enum class GameChapter(val chapterNum: Int, val title: String, val subtitle: String) {
    CHAPTER_1(1, "Розділ I: Зникнення", "Гірські околиці та спуск у ущелину"),
    CHAPTER_2(2, "Розділ II: Лабіринт лісоруба", "Шепітливий ліс та маєток лісопилки"),
    CHAPTER_3(3, "Розділ III: Сюрреалістичне спотворення", "Розколота реальність та остання правда")
}

data class DialogueChoice(
    val text: String,
    val nextNodeId: String?,
    val sanityDelta: Float = 0f,
    val actionTag: String? = null
)

data class DialogueNode(
    val id: String,
    val speaker: String,
    val voice: com.example.audio.DialogueVoice,
    val portrait: String, // e.g. "father_neutral", "father_shock", "leo_smile", "leo_scared", "woodcutter", "void"
    val text: String,
    val choices: List<DialogueChoice> = emptyList(),
    val nextNodeId: String? = null,
    val triggerAction: String? = null
)

data class GameSaveState(
    val chapter: Int = 1,
    val playerHp: Float = 100f,
    val playerSanity: Float = 100f,
    val revolverAmmoClip: Int = 6,
    val revolverReserve: Int = 18,
    val unlockedChapter: Int = 1,
    val foundNotes: Set<String> = emptySet(),
    val flags: Set<String> = emptySet(),
    val endingsUnlocked: Set<String> = emptySet(),
    val totalPlaytimeSeconds: Long = 0L
)

enum class EndingType(val title: String, val description: String) {
    ACCEPTANCE(
        title = "ФІНАЛ A: СВІТАНОК ПРИЙНЯТТЯ",
        description = "Ти тримав іграшкову машинку Лео, коли перші промені ранку пробилися крізь розбите лобове скло. Ти визнав те, що сталося тієї крижаної ночі на шосе. Туман відступив. Нарешті ти дозволив йому спочивати з миром."
    ),
    DENIAL(
        title = "ФІНАЛ B: БЕЗКІНЕЧНІ ПОШУКИ",
        description = "Ти відмовився дивитися на уламки. Ти повернувся спиною до дороги й знову поринув у темний лабіринт, вічно гукаючи його ім'я в плакучих тінях сосен."
    ),
    CYCLE(
        title = "ФІНАЛ C: ПЕТЛЯ ПАМ'ЯТІ",
        description = "Постріл розбив дзеркало реальності. Ти кліпнув — і знову опинився за кермом, фари розрізають туман, а Лео тихо наспівує на пасажирському сидінні."
    )
}
