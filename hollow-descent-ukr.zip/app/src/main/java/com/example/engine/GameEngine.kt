package com.example.engine

import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import com.example.audio.DialogueVoice
import com.example.audio.SoundSystem
import com.example.data.SaveManager
import com.example.model.*
import com.example.story.StoryDialogues
import com.example.world.MapZone
import com.example.world.Obstacle
import com.example.world.WorldData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.*
import kotlin.random.Random

class GameEngine(
    val soundSystem: SoundSystem,
    private val saveManager: SaveManager
) {
    // Current Game Chapter & Map
    var currentChapter: GameChapter = GameChapter.CHAPTER_1
        private set
    var currentMap: MapZone = WorldData.buildChapter1Map()
        private set

    // Player State
    var playerPos: Vector2 = currentMap.playerSpawn
    var playerVelocity: Vector2 = Vector2.Zero
    var playerFacing: Vector2 = Vector2.Down
    var playerHp: Float = 100f
    val maxPlayerHp: Float = 100f
    var playerSanity: Float = 100f
    val maxPlayerSanity: Float = 100f
    var equippedWeapon: WeaponType = WeaponType.BASEBALL_BAT
    var revolverAmmoClip: Int = 6
    val maxRevolverClip: Int = 6
    var revolverReserveAmmo: Int = 18
    var flashlightOn: Boolean = true

    // Combat timers
    var batCooldownTimer: Float = 0f
    var revolverCooldownTimer: Float = 0f
    var attackAnimTimer: Float = 0f
    var invincibilityTimer: Float = 0f
    var isSwingingBat: Boolean = false

    // Entities
    val monsters = mutableListOf<Monster>()
    val projectiles = mutableListOf<Projectile>()
    val particles = mutableListOf<Particle>()
    val floatingTexts = mutableListOf<FloatingCombatText>()

    // Narrative & Inventory
    val inventory = mutableListOf<InventoryItem>()
    val collectedNotes = mutableSetOf<String>()
    val storyFlags = mutableSetOf<String>()
    var currentInteractable: Interactable? = null

    // Screen Shake & Visual Distortions
    var screenShakeAmount: Float = 0f
    var screenBlinkAlpha: Float = 0f
    var psychologicalDistortionIntensity: Float = 0f

    // Dialogue State
    var activeDialogue: DialogueNode? = null
    var typewriterCharCount: Int = 0
    var typewriterTimer: Float = 0f
    var isDialogueComplete: Boolean = false

    // Cutscenes & States
    var isIntroCarCutscene: Boolean = true
    var carSpeedSimulation: Float = 60f
    var isGameOver: Boolean = false
    var activeEnding: EndingType? = null
    var isPaused: Boolean = false

    // Input state
    var movementInput: Vector2 = Vector2.Zero
    private var projectileIdCounter: Long = 0L

    // State flow for UI reactivity
    private val _uiStateTick = MutableStateFlow(0L)
    val uiStateTick = _uiStateTick.asStateFlow()

    init {
        loadInitialChapter(1)
    }

    fun loadInitialChapter(chapterNum: Int) {
        currentChapter = when (chapterNum) {
            1 -> GameChapter.CHAPTER_1
            2 -> GameChapter.CHAPTER_2
            else -> GameChapter.CHAPTER_3
        }
        currentMap = when (chapterNum) {
            1 -> WorldData.buildChapter1Map()
            2 -> WorldData.buildChapter2Map()
            else -> WorldData.buildChapter3Map()
        }
        playerPos = currentMap.playerSpawn
        playerVelocity = Vector2.Zero
        playerFacing = Vector2.Down
        monsters.clear()
        monsters.addAll(currentMap.initialMonsters)
        projectiles.clear()
        particles.clear()
        floatingTexts.clear()

        isGameOver = false
        activeEnding = null

        if (chapterNum == 1) {
            isIntroCarCutscene = true
            equippedWeapon = WeaponType.BASEBALL_BAT
            startDialogue("intro_car_1")
        } else {
            isIntroCarCutscene = false
            // Default inventory for later chapters if jumping straight in
            if (inventory.none { it.id == "bat" }) {
                inventory.add(InventoryItem("bat", "Ясеневий бейсбольний кий", "Зброя з багажника.", 1, ItemCategory.WEAPON))
                inventory.add(InventoryItem("revolver", "Револьвер .38", "Службова зброя.", 1, ItemCategory.WEAPON))
            }
            if (chapterNum == 2) {
                startDialogue("ch2_intro")
            } else if (chapterNum == 3) {
                startDialogue("ch3_intro")
            }
        }
    }

    fun update(deltaTime: Float) {
        if (isPaused || isGameOver || activeEnding != null) return

        val dt = deltaTime.coerceIn(0.001f, 0.05f)

        // Screen shake decay
        if (screenShakeAmount > 0f) {
            screenShakeAmount = (screenShakeAmount - dt * 15f).coerceAtLeast(0f)
        }
        if (screenBlinkAlpha > 0f) {
            screenBlinkAlpha = (screenBlinkAlpha - dt * 2f).coerceAtLeast(0f)
        }

        // Typewriter animation
        updateDialogue(dt)

        // Don't update world physics while full-screen cutscene or blocking dialogue is active
        if (activeDialogue != null && (isIntroCarCutscene || activeDialogue?.choices?.isNotEmpty() == true)) {
            return
        }

        // Timers
        if (batCooldownTimer > 0f) batCooldownTimer -= dt
        if (revolverCooldownTimer > 0f) revolverCooldownTimer -= dt
        if (attackAnimTimer > 0f) {
            attackAnimTimer -= dt
            if (attackAnimTimer <= 0f) isSwingingBat = false
        }
        if (invincibilityTimer > 0f) invincibilityTimer -= dt

        // Player movement
        val speed = if (isSwingingBat) 60f else 165f
        if (movementInput.length() > 0.05f) {
            val desiredVelocity = movementInput.normalized() * speed
            playerVelocity = desiredVelocity
            playerFacing = movementInput.normalized()
            // Footstep / ambience logic
        } else {
            playerVelocity = Vector2.Zero
        }

        val nextPlayerPos = playerPos + playerVelocity * dt
        playerPos = resolveMapCollision(playerPos, nextPlayerPos, radius = 18f)

        // Sanity & lighting effects
        if (!flashlightOn && currentChapter != GameChapter.CHAPTER_1) {
            playerSanity = (playerSanity - dt * 1.5f).coerceAtLeast(5f)
        } else {
            playerSanity = (playerSanity - dt * 0.2f).coerceAtLeast(10f)
        }

        // Projectiles
        val projIter = projectiles.iterator()
        while (projIter.hasNext()) {
            val p = projIter.next()
            p.pos = p.pos + p.velocity * dt
            p.lifeTimer -= dt

            var hit = false
            // Obstacle collision
            for (obs in currentMap.obstacles) {
                if (obs.bounds.contains(androidx.compose.ui.geometry.Offset(p.pos.x, p.pos.y))) {
                    hit = true
                    spawnSparks(p.pos, Color.Yellow)
                    break
                }
            }

            // Monster collision
            if (!hit && p.isPlayerBullet) {
                for (m in monsters) {
                    if (m.state != MonsterState.DEAD && m.pos.distanceTo(p.pos) < (m.attackRange + p.radius + 15f)) {
                        hit = true
                        damageMonster(m, p.damage, p.velocity.normalized() * 120f)
                        soundSystem.playBatHit()
                        break
                    }
                }
            }

            // Player hit by monster projectile
            if (!hit && !p.isPlayerBullet) {
                if (p.pos.distanceTo(playerPos) < (20f + p.radius)) {
                    hit = true
                    damagePlayer(p.damage)
                }
            }

            if (hit || p.lifeTimer <= 0f) {
                projIter.remove()
            }
        }

        // Monsters update
        val monsterIter = monsters.iterator()
        while (monsterIter.hasNext()) {
            val m = monsterIter.next()
            updateMonster(m, dt)
            if (m.state == MonsterState.DEAD && m.animTimer > 1.5f) {
                monsterIter.remove()
            }
        }

        // Particles
        val partIter = particles.iterator()
        while (partIter.hasNext()) {
            val part = partIter.next()
            part.pos = part.pos + part.velocity * dt
            part.life -= dt
            if (part.life <= 0f) partIter.remove()
        }

        // Floating texts
        val textIter = floatingTexts.iterator()
        while (textIter.hasNext()) {
            val txt = textIter.next()
            txt.pos = txt.pos + Vector2(0f, -28f * dt)
            txt.life -= dt
            if (txt.life <= 0f) textIter.remove()
        }

        // Update nearest interactable
        updateNearestInteractable()

        _uiStateTick.value += 1L
    }

    private fun updateMonster(m: Monster, dt: Float) {
        if (m.state == MonsterState.DEAD) {
            m.animTimer += dt
            return
        }

        m.animTimer += dt
        if (m.stunTimer > 0f) {
            m.stunTimer -= dt
            m.velocity = m.velocity * 0.88f
            m.pos = resolveMapCollision(m.pos, m.pos + m.velocity * dt, 20f)
            return
        }

        val distToPlayer = m.pos.distanceTo(playerPos)
        val dirToPlayer = (playerPos - m.pos).normalized()
        m.facingAngle = dirToPlayer.angleRad()

        if (m.attackCooldownTimer > 0f) m.attackCooldownTimer -= dt
        if (m.specialAttackTimer > 0f) m.specialAttackTimer -= dt

        // State Machine
        when (m.category) {
            MonsterCategory.MIST_WEEPER -> {
                if (distToPlayer < m.aggroRadius) {
                    m.state = MonsterState.CHASE
                    // Weepers dash in slightly winding paths
                    val wobbleAngle = m.facingAngle + sin(m.animTimer * 5f) * 0.45f
                    val moveDir = Vector2.fromAngle(wobbleAngle)
                    m.pos = resolveMapCollision(m.pos, m.pos + moveDir * m.speed * dt, 18f)

                    if (distToPlayer < m.attackRange && m.attackCooldownTimer <= 0f) {
                        damagePlayer(m.touchDamage)
                        m.attackCooldownTimer = 1.2f
                    }
                } else {
                    m.state = MonsterState.IDLE
                }
            }

            MonsterCategory.BRAMBLE_CRAWLER -> {
                if (distToPlayer < m.aggroRadius) {
                    m.state = MonsterState.CHASE
                    m.pos = resolveMapCollision(m.pos, m.pos + dirToPlayer * m.speed * dt, 16f)
                    if (distToPlayer < m.attackRange && m.attackCooldownTimer <= 0f) {
                        damagePlayer(m.touchDamage)
                        m.attackCooldownTimer = 1.0f
                    }
                }
            }

            MonsterCategory.GORGE_ECHO_BOSS -> {
                m.state = MonsterState.CHASE
                // Boss phases
                if (m.specialAttackTimer <= 0f) {
                    // Fire 3 shadowy projectile shards
                    soundSystem.playPsychologicalDistortion()
                    for (angleOffset in listOf(-0.35f, 0f, 0.35f)) {
                        val bulletDir = Vector2.fromAngle(m.facingAngle + angleOffset)
                        projectiles.add(
                            Projectile(
                                id = ++projectileIdCounter,
                                pos = m.pos,
                                velocity = bulletDir * 230f,
                                damage = 18f,
                                lifeTimer = 2.5f,
                                isPlayerBullet = false,
                                radius = 7f,
                                color = Color(0xFFCE93D8)
                            )
                        )
                    }
                    m.specialAttackTimer = if (m.hp < m.maxHp * 0.5f) 2.2f else 3.5f
                }

                // Moves towards player
                val bossSpeed = if (m.hp < m.maxHp * 0.4f) m.speed * 1.35f else m.speed
                m.pos = resolveMapCollision(m.pos, m.pos + dirToPlayer * bossSpeed * dt, 28f)

                if (distToPlayer < m.attackRange && m.attackCooldownTimer <= 0f) {
                    damagePlayer(m.touchDamage)
                    m.attackCooldownTimer = 1.4f
                }
            }

            MonsterCategory.TIMBER_LURKER -> {
                // Ambush predator: speeds up significantly when close
                if (distToPlayer < m.aggroRadius) {
                    val currentSpeed = if (distToPlayer < 120f) m.speed * 1.6f else m.speed
                    m.pos = resolveMapCollision(m.pos, m.pos + dirToPlayer * currentSpeed * dt, 22f)
                    if (distToPlayer < m.attackRange && m.attackCooldownTimer <= 0f) {
                        damagePlayer(m.touchDamage)
                        m.attackCooldownTimer = 1.6f
                        soundSystem.playBatHit()
                    }
                }
            }

            MonsterCategory.LANTERN_GHOUL -> {
                if (distToPlayer < m.aggroRadius) {
                    // Flies fast toward light
                    val ghoulSpeed = if (flashlightOn) m.speed * 1.25f else m.speed * 0.8f
                    m.pos = resolveMapCollision(m.pos, m.pos + dirToPlayer * ghoulSpeed * dt, 18f)
                    if (distToPlayer < m.attackRange && m.attackCooldownTimer <= 0f) {
                        damagePlayer(m.touchDamage)
                        m.attackCooldownTimer = 1.1f
                    }
                }
            }

            MonsterCategory.CORRUPTED_WOODCUTTER_BOSS -> {
                m.state = MonsterState.CHASE
                // Special broadaxe shockwave
                if (m.specialAttackTimer <= 0f) {
                    soundSystem.playBatSwing()
                    for (i in 0 until 5) {
                        val waveAngle = m.facingAngle + (i - 2) * 0.28f
                        projectiles.add(
                            Projectile(
                                id = ++projectileIdCounter,
                                pos = m.pos,
                                velocity = Vector2.fromAngle(waveAngle) * 260f,
                                damage = 22f,
                                lifeTimer = 2.0f,
                                isPlayerBullet = false,
                                radius = 9f,
                                color = Color(0xFFFF7043)
                            )
                        )
                    }
                    m.specialAttackTimer = 3.2f
                }
                m.pos = resolveMapCollision(m.pos, m.pos + dirToPlayer * m.speed * dt, 32f)
                if (distToPlayer < m.attackRange && m.attackCooldownTimer <= 0f) {
                    damagePlayer(m.touchDamage)
                    m.attackCooldownTimer = 1.5f
                }
            }

            MonsterCategory.STATIC_PHANTOM -> {
                if (distToPlayer < m.aggroRadius) {
                    // Occasionally teleports closer
                    if (m.specialAttackTimer <= 0f && distToPlayer > 130f) {
                        m.specialAttackTimer = 4.0f
                        soundSystem.playPsychologicalDistortion()
                        val teleportOffset = Vector2(Random.nextFloat() * 160f - 80f, Random.nextFloat() * 160f - 80f)
                        m.pos = resolveMapCollision(m.pos, playerPos + teleportOffset, 20f)
                        spawnSparks(m.pos, Color.Cyan)
                    } else {
                        m.pos = resolveMapCollision(m.pos, m.pos + dirToPlayer * m.speed * dt, 20f)
                    }

                    if (distToPlayer < m.attackRange && m.attackCooldownTimer <= 0f) {
                        damagePlayer(m.touchDamage)
                        m.attackCooldownTimer = 1.1f
                    }
                }
            }

            MonsterCategory.GUILT_WEAVER -> {
                // Stationary or very slow eye spire that shoots red guilt beams
                if (distToPlayer < m.aggroRadius) {
                    if (m.specialAttackTimer <= 0f) {
                        projectiles.add(
                            Projectile(
                                id = ++projectileIdCounter,
                                pos = m.pos,
                                velocity = dirToPlayer * 210f,
                                damage = 24f,
                                lifeTimer = 3.0f,
                                isPlayerBullet = false,
                                radius = 10f,
                                color = Color(0xFFE91E63)
                            )
                        )
                        m.specialAttackTimer = 2.2f
                    }
                }
            }

            MonsterCategory.THE_VOID_BOSS -> {
                // Final Boss
                m.state = MonsterState.CHASE
                // Multi-phase bullet hell spiral & void blasts
                if (m.specialAttackTimer <= 0f) {
                    soundSystem.playPsychologicalDistortion()
                    val numProjectiles = if (m.hp < m.maxHp * 0.4f) 8 else 6
                    for (i in 0 until numProjectiles) {
                        val angle = (i.toFloat() / numProjectiles) * (2f * PI.toFloat()) + m.animTimer * 2f
                        projectiles.add(
                            Projectile(
                                id = ++projectileIdCounter,
                                pos = m.pos,
                                velocity = Vector2.fromAngle(angle) * 200f,
                                damage = 20f,
                                lifeTimer = 2.8f,
                                isPlayerBullet = false,
                                radius = 8f,
                                color = Color(0xFFAB47BC)
                            )
                        )
                    }
                    m.specialAttackTimer = if (m.hp < m.maxHp * 0.5f) 1.8f else 2.6f
                }

                m.pos = resolveMapCollision(m.pos, m.pos + dirToPlayer * m.speed * dt, 36f)
                if (distToPlayer < m.attackRange && m.attackCooldownTimer <= 0f) {
                    damagePlayer(m.touchDamage)
                    m.attackCooldownTimer = 1.3f
                }
            }
        }
    }

    fun onMeleeSwing() {
        if (batCooldownTimer > 0f || isSwingingBat) return

        isSwingingBat = true
        attackAnimTimer = 0.25f
        batCooldownTimer = WeaponType.BASEBALL_BAT.cooldown
        soundSystem.playBatSwing()

        // Check melee cone in front of player
        val swingRange = 75f
        val swingConeDegrees = 110f
        var hitAny = false

        for (m in monsters) {
            if (m.state == MonsterState.DEAD) continue
            val dist = playerPos.distanceTo(m.pos)
            if (dist <= swingRange) {
                val toMonster = (m.pos - playerPos).normalized()
                val dot = playerFacing.x * toMonster.x + playerFacing.y * toMonster.y
                val angleDeg = acos(dot.coerceIn(-1f, 1f)) * 180f / PI.toFloat()
                if (angleDeg <= swingConeDegrees / 2f) {
                    hitAny = true
                    damageMonster(m, WeaponType.BASEBALL_BAT.damage, playerFacing * 280f)
                    spawnSparks(m.pos, Color.White)
                }
            }
        }

        if (hitAny) {
            soundSystem.playBatHit()
            screenShakeAmount = 6f
        }
    }

    fun onFireRevolver() {
        if (revolverCooldownTimer > 0f) return

        if (revolverAmmoClip <= 0) {
            soundSystem.playGunEmpty()
            floatingTexts.add(FloatingCombatText("ПОРОЖНЬО!", playerPos + Vector2(0f, -35f), Color.Red))
            return
        }

        revolverAmmoClip--
        revolverCooldownTimer = WeaponType.REVOLVER.cooldown
        soundSystem.playGunshot()
        screenShakeAmount = 9f

        // Spawn bullet projectile
        val bulletSpawnPos = playerPos + playerFacing * 25f
        projectiles.add(
            Projectile(
                id = ++projectileIdCounter,
                pos = bulletSpawnPos,
                velocity = playerFacing * 700f,
                damage = WeaponType.REVOLVER.damage,
                lifeTimer = 1.3f,
                isPlayerBullet = true,
                radius = 5f,
                color = Color(0xFFFFEB3B)
            )
        )

        // Muzzle flash particle
        for (i in 0 until 6) {
            val angle = playerFacing.angleRad() + (Random.nextFloat() * 0.6f - 0.3f)
            particles.add(
                Particle(
                    pos = bulletSpawnPos,
                    velocity = Vector2.fromAngle(angle) * (Random.nextFloat() * 90f + 60f),
                    color = Color(0xFFFFD54F),
                    size = Random.nextFloat() * 4f + 3f,
                    life = 0.15f,
                    maxLife = 0.15f
                )
            )
        }
    }

    fun onReloadRevolver() {
        if (revolverAmmoClip >= maxRevolverClip) return
        val needed = maxRevolverClip - revolverAmmoClip
        if (revolverReserveAmmo <= 0) {
            floatingTexts.add(FloatingCombatText("НЕМАЄ НАБОЇВ!", playerPos + Vector2(0f, -35f), Color.Red))
            soundSystem.playGunEmpty()
            return
        }
        val toLoad = minOf(needed, revolverReserveAmmo)
        revolverReserveAmmo -= toLoad
        revolverAmmoClip += toLoad
        soundSystem.playReload()
        floatingTexts.add(FloatingCombatText("ПЕРЕЗАРЯДЖЕНО", playerPos + Vector2(0f, -35f), Color.Green))
    }

    fun onToggleWeapon() {
        equippedWeapon = if (equippedWeapon == WeaponType.BASEBALL_BAT) {
            WeaponType.REVOLVER
        } else {
            WeaponType.BASEBALL_BAT
        }
    }

    fun onToggleFlashlight() {
        flashlightOn = !flashlightOn
        soundSystem.playFlashlightClick()
    }

    fun damagePlayer(amount: Float) {
        if (invincibilityTimer > 0f || isGameOver) return
        playerHp -= amount
        invincibilityTimer = 0.85f
        screenShakeAmount = 14f
        soundSystem.playPlayerHurt()

        floatingTexts.add(
            FloatingCombatText(
                "-${amount.toInt()}",
                playerPos + Vector2(0f, -30f),
                Color(0xFFFF5252)
            )
        )

        if (playerHp <= 0f) {
            playerHp = 0f
            isGameOver = true
        }
    }

    fun damageMonster(m: Monster, damage: Float, knockback: Vector2) {
        m.hp -= damage
        m.stunTimer = 0.35f
        m.velocity = knockback

        floatingTexts.add(
            FloatingCombatText(
                "-${damage.toInt()}",
                m.pos + Vector2(0f, -25f),
                Color(0xFFFFE082)
            )
        )

        // Spawn hit blood/mist particles
        for (i in 0 until 5) {
            particles.add(
                Particle(
                    pos = m.pos,
                    velocity = Vector2(Random.nextFloat() * 120f - 60f, Random.nextFloat() * 120f - 60f),
                    color = if (m.category == MonsterCategory.STATIC_PHANTOM) Color.Cyan else Color(0xFF7E57C2),
                    size = Random.nextFloat() * 4f + 3f,
                    life = 0.3f,
                    maxLife = 0.3f
                )
            )
        }

        if (m.hp <= 0f) {
            m.hp = 0f
            m.state = MonsterState.DEAD
            m.animTimer = 0f
            onMonsterDefeated(m)
        }
    }

    private fun onMonsterDefeated(m: Monster) {
        soundSystem.playMonsterRoar(currentChapter.chapterNum)
        // Check boss defeat
        if (m.isBoss) {
            when (m.category) {
                MonsterCategory.GORGE_ECHO_BOSS -> {
                    startDialogue("boss1_post")
                }
                MonsterCategory.CORRUPTED_WOODCUTTER_BOSS -> {
                    startDialogue("boss2_post")
                }
                MonsterCategory.THE_VOID_BOSS -> {
                    startDialogue("final_choice_node")
                }
                else -> {}
            }
        }
    }

    private fun updateNearestInteractable() {
        var closest: Interactable? = null
        var closestDist = Float.MAX_VALUE
        for (item in currentMap.interactables) {
            if (item.isCollected) continue
            val dist = playerPos.distanceTo(item.pos)
            if (dist <= item.radius && dist < closestDist) {
                closest = item
                closestDist = dist
            }
        }
        currentInteractable = closest
    }

    fun onInteract() {
        val target = currentInteractable ?: return

        when (target.type) {
            InteractableType.CAR_GLOVEBOX -> {
                target.isCollected = true
                inventory.add(InventoryItem("revolver", "Револьвер .38", "Службова зброя з бардачка.", 1, ItemCategory.WEAPON))
                revolverReserveAmmo += 12
                soundSystem.playItemPickup()
                startDialogue("inspect_glovebox")
            }

            InteractableType.CAR_TRUNK -> {
                target.isCollected = true
                inventory.add(InventoryItem("bat", "Ясеневий бейсбольний кий", "Бита з багажника.", 1, ItemCategory.WEAPON))
                inventory.add(InventoryItem("flashlight", "Тактичний ліхтар", "Пронизливий промінь.", 1, ItemCategory.KEY))
                soundSystem.playItemPickup()
                startDialogue("inspect_trunk")
            }

            InteractableType.CRAG_DESCENT_LEDGE -> {
                if (!storyFlags.contains("WEAPONS_RETRIEVED")) {
                    floatingTexts.add(FloatingCombatText("Спершу огляньте авто!", playerPos + Vector2(0f, -30f), Color.Yellow))
                    return
                }
                startDialogue("leo_distant_shout")
            }

            InteractableType.NOTE -> {
                collectedNotes.add(target.id)
                soundSystem.playItemPickup()
                val dialogueId = when (target.id) {
                    "radio_shed_note" -> "woodcutter_note_1"
                    "ch2_note_1" -> "woodcutter_note_1"
                    "ch2_note_2" -> "woodcutter_note_2"
                    else -> null
                }
                if (dialogueId != null) {
                    startDialogue(dialogueId)
                } else {
                    floatingTexts.add(FloatingCombatText(target.name, playerPos + Vector2(0f, -30f), Color.Cyan))
                }
            }

            InteractableType.AMMO_PICKUP -> {
                target.isCollected = true
                revolverReserveAmmo += 6
                soundSystem.playItemPickup()
                floatingTexts.add(FloatingCombatText("+6 куль", playerPos + Vector2(0f, -30f), Color.Yellow))
            }

            InteractableType.MEDKIT_PICKUP -> {
                target.isCollected = true
                playerHp = (playerHp + 50f).coerceAtMost(maxPlayerHp)
                soundSystem.playItemPickup()
                floatingTexts.add(FloatingCombatText("+50 HP", playerPos + Vector2(0f, -30f), Color.Green))
            }

            InteractableType.SANITY_MEDS -> {
                target.isCollected = true
                playerSanity = (playerSanity + 60f).coerceAtMost(maxPlayerSanity)
                soundSystem.playItemPickup()
                floatingTexts.add(FloatingCombatText("+60 розсудку", playerPos + Vector2(0f, -30f), Color.Cyan))
            }

            InteractableType.SAVE_LANTERN -> {
                playerSanity = maxPlayerSanity
                playerHp = (playerHp + 30f).coerceAtMost(maxPlayerHp)
                soundSystem.playItemPickup()
                floatingTexts.add(FloatingCombatText("ЗБЕРЕЖЕНО Й ВІДПОЧИТО", playerPos + Vector2(0f, -30f), Color.Green))
                saveGameState()
            }

            InteractableType.KEY_ITEM -> {
                target.isCollected = true
                inventory.add(InventoryItem(target.id, target.name, target.description, 1, ItemCategory.KEY))
                soundSystem.playItemPickup()
                floatingTexts.add(FloatingCombatText("Отримано: ${target.name}", playerPos + Vector2(0f, -30f), Color.Cyan))
            }

            InteractableType.GENERATOR_SWITCH -> {
                val hasF1 = inventory.any { it.id == "fuse_1" }
                val hasF2 = inventory.any { it.id == "fuse_2" }
                val hasF3 = inventory.any { it.id == "fuse_3" }
                if (hasF1 && hasF2 && hasF3) {
                    target.isCollected = true
                    storyFlags.add("SAWMILL_POWERED")
                    soundSystem.playItemPickup()
                    startDialogue("generator_activated")
                } else {
                    val count = (if (hasF1) 1 else 0) + (if (hasF2) 1 else 0) + (if (hasF3) 1 else 0)
                    floatingTexts.add(FloatingCombatText("Запобіжники: $count/3 вставлено", playerPos + Vector2(0f, -30f), Color.Red))
                }
            }

            else -> {}
        }
    }

    private fun resolveMapCollision(current: Vector2, desired: Vector2, radius: Float): Vector2 {
        var resolved = desired

        for (obs in currentMap.obstacles) {
            val rect = obs.bounds
            // Expand rectangle by entity radius for circle-box test
            val expandedLeft = rect.left - radius
            val expandedTop = rect.top - radius
            val expandedRight = rect.right + radius
            val expandedBottom = rect.bottom + radius

            if (resolved.x in expandedLeft..expandedRight && resolved.y in expandedTop..expandedBottom) {
                // Resolve X first
                val testX = Vector2(resolved.x, current.y)
                if (testX.x in expandedLeft..expandedRight && current.y in expandedTop..expandedBottom) {
                    // collided in X, revert X
                    resolved = Vector2(current.x, resolved.y)
                }

                // Resolve Y
                val testY = Vector2(resolved.x, resolved.y)
                if (resolved.x in expandedLeft..expandedRight && testY.y in expandedTop..expandedBottom) {
                    resolved = Vector2(resolved.x, current.y)
                }
            }
        }

        // Clamp to map bounds
        val clampedX = resolved.x.coerceIn(radius, currentMap.width - radius)
        val clampedY = resolved.y.coerceIn(radius, currentMap.height - radius)
        return Vector2(clampedX, clampedY)
    }

    private fun spawnSparks(pos: Vector2, color: Color) {
        for (i in 0 until 4) {
            particles.add(
                Particle(
                    pos = pos,
                    velocity = Vector2(Random.nextFloat() * 100f - 50f, Random.nextFloat() * 100f - 50f),
                    color = color,
                    size = 3f,
                    life = 0.2f,
                    maxLife = 0.2f
                )
            )
        }
    }

    fun startDialogue(dialogueId: String) {
        val node = StoryDialogues.getNode(dialogueId) ?: return
        activeDialogue = node
        typewriterCharCount = 0
        typewriterTimer = 0f
        isDialogueComplete = false
    }

    private fun updateDialogue(dt: Float) {
        val node = activeDialogue ?: return
        if (isDialogueComplete) return

        typewriterTimer += dt
        val speedPerChar = 0.025f
        if (typewriterTimer >= speedPerChar) {
            typewriterTimer = 0f
            if (typewriterCharCount < node.text.length) {
                typewriterCharCount++
                if (typewriterCharCount % 2 == 0) {
                    soundSystem.playDialogueBlip(node.voice)
                }
            } else {
                isDialogueComplete = true
            }
        }
    }

    fun onAdvanceDialogue() {
        val node = activeDialogue ?: return

        // If typewriter is still typing, complete it immediately on first tap
        if (!isDialogueComplete) {
            typewriterCharCount = node.text.length
            isDialogueComplete = true
            return
        }

        // If there are choices, player must pick a choice button
        if (node.choices.isNotEmpty()) return

        // Execute action if any
        handleDialogueAction(node.triggerAction)

        // Advance to next node or close
        val next = node.nextNodeId
        if (next != null) {
            startDialogue(next)
        } else {
            activeDialogue = null
        }
    }

    fun onSelectDialogueChoice(choice: DialogueChoice) {
        val node = activeDialogue ?: return
        playerSanity = (playerSanity + choice.sanityDelta).coerceIn(0f, maxPlayerSanity)
        handleDialogueAction(choice.actionTag)

        val nextId = choice.nextNodeId
        if (nextId != null) {
            startDialogue(nextId)
        } else {
            activeDialogue = null
        }
    }

    private fun handleDialogueAction(action: String?) {
        when (action) {
            "TRIGGER_DISAPPEARANCE" -> {
                screenBlinkAlpha = 1.0f
                screenShakeAmount = 25f
                soundSystem.playPsychologicalDistortion()
                isIntroCarCutscene = false
            }
            "START_CAR_INVESTIGATION" -> {
                storyFlags.add("CAR_INVESTIGATION_STARTED")
            }
            "UNLOCK_REVOLVER" -> {
                storyFlags.add("REVOLVER_FOUND")
                checkWeaponsRetrieved()
            }
            "UNLOCK_BAT_AND_LIGHT" -> {
                storyFlags.add("BAT_FOUND")
                checkWeaponsRetrieved()
            }
            "UNLOCK_ROAD_GATE" -> {
                storyFlags.add("ROAD_GATE_UNLOCKED")
                // Teleport player down to gorge descent
                playerPos = Vector2(850f, 540f)
            }
            "START_BOSS_1" -> {
                soundSystem.playMonsterRoar(1)
            }
            "TRANSITION_CHAPTER_2" -> {
                saveManager.setHighestChapterUnlocked(2)
                loadInitialChapter(2)
            }
            "START_BOSS_2" -> {
                soundSystem.playMonsterRoar(2)
            }
            "TRANSITION_CHAPTER_3" -> {
                saveManager.setHighestChapterUnlocked(3)
                loadInitialChapter(3)
            }
            "START_FINAL_BOSS" -> {
                soundSystem.playMonsterRoar(3)
            }
            "TRIGGER_ENDING_A" -> {
                saveManager.unlockEnding("ENDING_A")
                activeEnding = EndingType.ACCEPTANCE
                activeDialogue = null
            }
            "TRIGGER_ENDING_B" -> {
                saveManager.unlockEnding("ENDING_B")
                activeEnding = EndingType.DENIAL
                activeDialogue = null
            }
            "TRIGGER_ENDING_C" -> {
                saveManager.unlockEnding("ENDING_C")
                activeEnding = EndingType.CYCLE
                activeDialogue = null
            }
            "SHOW_ENDING_SCREEN_A" -> {
                activeEnding = EndingType.ACCEPTANCE
                activeDialogue = null
            }
            "SHOW_ENDING_SCREEN_B" -> {
                activeEnding = EndingType.DENIAL
                activeDialogue = null
            }
            "SHOW_ENDING_SCREEN_C" -> {
                activeEnding = EndingType.CYCLE
                activeDialogue = null
            }
            else -> {}
        }
    }

    private fun checkWeaponsRetrieved() {
        if (storyFlags.contains("REVOLVER_FOUND") && storyFlags.contains("BAT_FOUND")) {
            storyFlags.add("WEAPONS_RETRIEVED")
            startDialogue("leo_distant_shout")
        }
    }

    fun saveGameState() {
        saveManager.saveGame(
            GameSaveState(
                chapter = currentChapter.chapterNum,
                playerHp = playerHp,
                playerSanity = playerSanity,
                revolverAmmoClip = revolverAmmoClip,
                revolverReserve = revolverReserveAmmo,
                unlockedChapter = maxOf(currentChapter.chapterNum, saveManager.getHighestChapterUnlocked()),
                foundNotes = collectedNotes,
                flags = storyFlags,
                endingsUnlocked = saveManager.getUnlockedEndings()
            )
        )
    }

    fun restartCurrentChapter() {
        loadInitialChapter(currentChapter.chapterNum)
    }
}
