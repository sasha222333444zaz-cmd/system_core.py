package com.example.story

import com.example.audio.DialogueVoice
import com.example.model.DialogueChoice
import com.example.model.DialogueNode

object StoryDialogues {

    val dialogues: Map<String, DialogueNode> = listOf(
        // ================= CHAPTER 1 INTRO =================
        DialogueNode(
            id = "intro_car_1",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_tired",
            text = "Уже по півночі, Лео. Спробуй поспати. Нам ще дві години до бабусиної хатини.",
            nextNodeId = "intro_car_2"
        ),
        DialogueNode(
            id = "intro_car_2",
            speaker = "Лео (Син)",
            voice = DialogueVoice.LEO,
            portrait = "leo_worried",
            text = "Я пробував, тату... але надворі такий густий туман. А сосни схожі на людей, що стоять край дороги.",
            choices = listOf(
                DialogueChoice(
                    text = "Це просто дерева, синку. Твоя уява розігралася.",
                    nextNodeId = "intro_car_3a",
                    sanityDelta = 5f
                ),
                DialogueChoice(
                    text = "Дивися на свою машинку, Лео. Не дивися у вікно.",
                    nextNodeId = "intro_car_3b",
                    sanityDelta = -5f
                )
            )
        ),
        DialogueNode(
            id = "intro_car_3a",
            speaker = "Лео (Син)",
            voice = DialogueVoice.LEO,
            portrait = "leo_neutral",
            text = "Я знаю... але одна з них махала рукою. У неї не було обличчя, тату. Лише дві світні цятки там, де мають бути очі.",
            nextNodeId = "intro_car_4"
        ),
        DialogueNode(
            id = "intro_car_3b",
            speaker = "Лео (Син)",
            voice = DialogueVoice.LEO,
            portrait = "leo_worried",
            text = "Добре... Тату? Чому мама лишилася? Ти казав, що вона поїде пізнішим потягом, але її валіза досі стояла біля дверей...",
            nextNodeId = "intro_car_4"
        ),
        DialogueNode(
            id = "intro_car_4",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_hesitant",
            text = "Ми... ми ж про це говорили, Лео. Усе буде добре, щойно ми проїдемо хребет Блеквуд.",
            nextNodeId = "intro_car_5"
        ),
        DialogueNode(
            id = "intro_car_5",
            speaker = "Радіо",
            voice = DialogueVoice.RADIO,
            portrait = "radio_static",
            text = "[ТРІСК ЕФІРУ] ...Штормове попередження на трасі 9... Сильна ожеледиця... Масове зіткнення авто поблизу 14-ї милі...",
            nextNodeId = "intro_car_6"
        ),
        DialogueNode(
            id = "intro_car_6",
            speaker = "Лео (Син)",
            voice = DialogueVoice.LEO,
            portrait = "leo_scared",
            text = "Тату? Чому фари стали червоними? ТАТУ?! ХТО ТАМ ПЕРЕД МАШИНОЮ?!",
            nextNodeId = "intro_car_blink"
        ),
        DialogueNode(
            id = "intro_car_blink",
            speaker = "Система",
            voice = DialogueVoice.SYSTEM,
            portrait = "system_dark",
            text = "[Раптовий оглушливий вереск шин — спалах сліпучого білого світла — і абсолютна, задушлива тиша.]",
            triggerAction = "TRIGGER_DISAPPEARANCE",
            nextNodeId = "intro_aftermath_1"
        ),
        DialogueNode(
            id = "intro_aftermath_1",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_shock",
            text = "Лео?! ЛЕО! ...Машина зупинилась. Пасажирське сидіння... порожнє?! Лише його маленька червона куртка!",
            nextNodeId = "intro_aftermath_2"
        ),
        DialogueNode(
            id = "intro_aftermath_2",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_shock",
            text = "Треба оглянути авто. Бардачок, багажник... і негайно знайти мого хлопчика!",
            triggerAction = "START_CAR_INVESTIGATION"
        ),

        // ================= CAR SEARCH =================
        DialogueNode(
            id = "inspect_glovebox",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_neutral",
            text = "Бардачок. Мій старий службовий револьвер (.38 Special) і коробка набоїв. Я клявся, що більше ніколи його не торкнуся... але в цьому тумані ризикувати не можна.",
            triggerAction = "UNLOCK_REVOLVER"
        ),
        DialogueNode(
            id = "inspect_trunk",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_neutral",
            text = "У багажнику: ясенева бейсбольна бита й потужний тактичний ліхтар. Добре для ближнього бою і щоб прорізати цю неприродну темряву.",
            triggerAction = "UNLOCK_BAT_AND_LIGHT"
        ),
        DialogueNode(
            id = "leo_distant_shout",
            speaker = "Відлуння Лео",
            voice = DialogueVoice.LEO,
            portrait = "leo_scared",
            text = "Тату! Допоможи! Тут так темно... Я чую, як щось шкрябає по камінню!",
            nextNodeId = "leo_distant_shout_2"
        ),
        DialogueNode(
            id = "leo_distant_shout_2",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_shock",
            text = "Його голос! Він лунає з-під зламаного відбійника, з гірської ущелини! Тримайся, Лео, я йду!",
            triggerAction = "UNLOCK_ROAD_GATE"
        ),

        // ================= CHAPTER 1 GORGE BOSS =================
        DialogueNode(
            id = "boss1_pre",
            speaker = "Плакучий силует",
            voice = DialogueVoice.THE_VOID,
            portrait = "void_silhouette",
            text = "Ти заснув, Артуре... ти залишив його на холоді... чому ти заплющив очі за кермом?",
            choices = listOf(
                DialogueChoice(
                    text = "Замовкни! Поверни мені сина!",
                    nextNodeId = "boss1_fight",
                    sanityDelta = -10f
                ),
                DialogueChoice(
                    text = "Хто ти?! Що сталося з Лео?!",
                    nextNodeId = "boss1_fight",
                    sanityDelta = 0f
                )
            )
        ),
        DialogueNode(
            id = "boss1_fight",
            speaker = "Відлуння ущелини",
            voice = DialogueVoice.THE_VOID,
            portrait = "void_beast",
            text = "ТЕПЕР ВІН НАЛЕЖИТЬ ГОРІ! ВІДЧУЙ ЛІД!",
            triggerAction = "START_BOSS_1"
        ),
        DialogueNode(
            id = "boss1_post",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_tired",
            text = "Воно розсипалося чорним туманом... але глянь на землю: маленькі сліди кросівок ведуть прямо в глибокий ліс. Шлях відкрито...",
            triggerAction = "TRANSITION_CHAPTER_2"
        ),

        // ================= CHAPTER 2 DIALOGUES =================
        DialogueNode(
            id = "ch2_intro",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_neutral",
            text = "Дерева тут величезні, прадавні... наче чорні ребра на тлі неба. Попереду — покинута лісопилка й маєток лісоруба. Залізна брама мертва без струму.",
            nextNodeId = "ch2_intro_hint"
        ),
        DialogueNode(
            id = "ch2_intro_hint",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_neutral",
            text = "Треба прочесати ліс у пошуках запобіжників для генератора й остерігатися тих, хто чатує серед стовбурів."
        ),
        DialogueNode(
            id = "woodcutter_note_1",
            speaker = "Обірваний запис у щоденнику",
            voice = DialogueVoice.SYSTEM,
            portrait = "note_paper",
            text = "'19 жовтня — Туман говорить голосами тих, кого ми занапастили недбалістю. Я чую, як донька кличе з колодязя, але вона померла дванадцять зим тому... Сокира — мій єдиний спокій.'"
        ),
        DialogueNode(
            id = "woodcutter_note_2",
            speaker = "Журнал шерифа про аварії",
            voice = DialogueVoice.SYSTEM,
            portrait = "note_paper",
            text = "'Справа №94-B: перевал Блеквуд. Батько вижив, легкі струси. Дитину констатовано на місці... Стривайте, чому моє ім'я, Артур Венс, штампом внизу цього офіційного висновку коронера?!'"
        ),
        DialogueNode(
            id = "generator_activated",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_neutral",
            text = "Усі запобіжники на місці! Дизельний генератор заревів. Прожектори освітили двір лісопилки, а брама маєтку клацнула й відчинилась!"
        ),
        DialogueNode(
            id = "boss2_pre",
            speaker = "Осквернений лісоруб",
            voice = DialogueVoice.WOODCUTTER,
            portrait = "woodcutter_axe",
            text = "Ще один блукалець, що не хоче ховати своїх мертвих! Дерева жадають скорботи батьків у жалобі! Твоя кров удобрить коріння!",
            choices = listOf(
                DialogueChoice(
                    text = "Геть з дороги! Мій хлопчик там, усередині!",
                    nextNodeId = "boss2_fight",
                    sanityDelta = -5f
                ),
                DialogueChoice(
                    text = "Я не піду без правди!",
                    nextNodeId = "boss2_fight",
                    sanityDelta = 5f
                )
            )
        ),
        DialogueNode(
            id = "boss2_fight",
            speaker = "Осквернений лісоруб",
            voice = DialogueVoice.WOODCUTTER,
            portrait = "woodcutter_axe",
            text = "ТОДІ НЕХАЙ СОКИРА РОЗСІЧЕ ТВОЇ ІЛЮЗІЇ!",
            triggerAction = "START_BOSS_2"
        ),
        DialogueNode(
            id = "boss2_post",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_shock",
            text = "Підлога лісопилки провалилася... але під цим пагорбом немає підвалів. Це вируюча воронка розбитого скла й дорожніх знаків, що пливуть у повітрі... Реальність розпадається!",
            triggerAction = "TRANSITION_CHAPTER_3"
        ),

        // ================= CHAPTER 3 DIALOGUES =================
        DialogueNode(
            id = "ch3_intro",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_shock",
            text = "Де... де я? Дорога розбита на літаючі острови. Нічне небо повне червоних сирен і соснових верхівок догори дриґом. А ось моя машина, застигла в повітрі серед уламків безпечного скла!",
            nextNodeId = "ch3_intro_2"
        ),
        DialogueNode(
            id = "ch3_intro_2",
            speaker = "Голос Лео (з порожнечі)",
            voice = DialogueVoice.LEO,
            portrait = "leo_neutral",
            text = "Тату... ти тепер пам'ятаєш? Ти так втомився після подвійної зміни. Ти казав мені, що лише на п'ять секунд заплющив очі...",
            nextNodeId = "ch3_intro_3"
        ),
        DialogueNode(
            id = "ch3_intro_3",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_shock",
            text = "Ні... ні, я не засинав! Ми їхали до бабусі! Вранці ми мали піти на рибалку!",
            nextNodeId = "ch3_intro_4"
        ),
        DialogueNode(
            id = "ch3_intro_4",
            speaker = "Втілена провина",
            voice = DialogueVoice.THE_VOID,
            portrait = "void_beast",
            text = "ТИ З'ЇХАВ ІЗ НАСИПУ. ПОДИВИСЬ НА ВЛАСНІ РУКИ, АРТУРЕ. ЗУСТРІНЬСЯ З ТИМ, ЩО ЗРОБИВ, АБО ВІЧНО ГОРИ В ЦІЙ В'ЯЗНИЦІ!",
            triggerAction = "START_FINAL_BOSS"
        ),

        // ================= POST-FINAL BOSS / ENDING CHOICES =================
        DialogueNode(
            id = "final_choice_node",
            speaker = "Лео (духовний образ)",
            voice = DialogueVoice.LEO,
            portrait = "leo_smile",
            text = "Тату... ти так відчайдушно пробивався до мене крізь темряву. Але це не твоя вина. Ожеледиця була скрізь. Що ти зробиш тепер?",
            choices = listOf(
                DialogueChoice(
                    text = "[Прийняття] Обійняти Лео, прийняти горе й ступити назустріч сонцю, що сходить.",
                    nextNodeId = "ending_acceptance",
                    sanityDelta = 50f,
                    actionTag = "TRIGGER_ENDING_A"
                ),
                DialogueChoice(
                    text = "[Заперечення] Не відпускати його. Побігти назад у ліс шукати вічно.",
                    nextNodeId = "ending_denial",
                    sanityDelta = -50f,
                    actionTag = "TRIGGER_ENDING_B"
                ),
                DialogueChoice(
                    text = "[Петля] Вистрелити з револьвера в небо порожнечі, щоб скинути час.",
                    nextNodeId = "ending_cycle",
                    sanityDelta = 0f,
                    actionTag = "TRIGGER_ENDING_C"
                )
            )
        ),
        DialogueNode(
            id = "ending_acceptance",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_peace",
            text = "Я люблю тебе, Лео. Завжди любитиму. Пробач, що не зміг тебе врятувати... але я більше не тікатиму від твоєї пам'яті. Спи спокійно, мій хлопчику.",
            triggerAction = "SHOW_ENDING_SCREEN_A"
        ),
        DialogueNode(
            id = "ending_denial",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_shock",
            text = "Ні! Ти живий! Ти просто ховаєшся від мене за соснами! Я обшукаю кожен метр цієї долини, поки не приведу тебе додому!",
            triggerAction = "SHOW_ENDING_SCREEN_B"
        ),
        DialogueNode(
            id = "ending_cycle",
            speaker = "Артур (Батько)",
            voice = DialogueVoice.FATHER,
            portrait = "father_neutral",
            text = "[БАХ!] ...Відлуння розриває кошмар. Ти заплющуєш очі... і чуєш гудіння двигуна седана під дощем.",
            triggerAction = "SHOW_ENDING_SCREEN_C"
        )
    ).associateBy { it.id }

    fun getNode(id: String): DialogueNode? = dialogues[id]
}
