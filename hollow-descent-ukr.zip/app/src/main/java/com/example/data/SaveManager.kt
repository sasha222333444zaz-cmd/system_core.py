package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.GameSaveState

class SaveManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("hollow_descent_save", Context.MODE_PRIVATE)

    fun saveGame(state: GameSaveState) {
        prefs.edit().apply {
            putInt(KEY_CHAPTER, state.chapter)
            putFloat(KEY_PLAYER_HP, state.playerHp)
            putFloat(KEY_PLAYER_SANITY, state.playerSanity)
            putInt(KEY_AMMO_CLIP, state.revolverAmmoClip)
            putInt(KEY_AMMO_RESERVE, state.revolverReserve)
            putInt(KEY_UNLOCKED_CHAPTER, maxOf(state.unlockedChapter, prefs.getInt(KEY_UNLOCKED_CHAPTER, 1)))
            putStringSet(KEY_FOUND_NOTES, state.foundNotes)
            putStringSet(KEY_FLAGS, state.flags)
            putStringSet(KEY_ENDINGS, state.endingsUnlocked)
            putLong(KEY_PLAYTIME, state.totalPlaytimeSeconds)
            apply()
        }
    }

    fun loadGame(): GameSaveState {
        val chapter = prefs.getInt(KEY_CHAPTER, 1)
        val hp = prefs.getFloat(KEY_PLAYER_HP, 100f)
        val sanity = prefs.getFloat(KEY_PLAYER_SANITY, 100f)
        val clip = prefs.getInt(KEY_AMMO_CLIP, 6)
        val reserve = prefs.getInt(KEY_AMMO_RESERVE, 18)
        val unlockedChapter = prefs.getInt(KEY_UNLOCKED_CHAPTER, 1)
        val notes = prefs.getStringSet(KEY_FOUND_NOTES, emptySet()) ?: emptySet()
        val flags = prefs.getStringSet(KEY_FLAGS, emptySet()) ?: emptySet()
        val endings = prefs.getStringSet(KEY_ENDINGS, emptySet()) ?: emptySet()
        val playtime = prefs.getLong(KEY_PLAYTIME, 0L)

        return GameSaveState(
            chapter = chapter,
            playerHp = hp,
            playerSanity = sanity,
            revolverAmmoClip = clip,
            revolverReserve = reserve,
            unlockedChapter = unlockedChapter,
            foundNotes = notes,
            flags = flags,
            endingsUnlocked = endings,
            totalPlaytimeSeconds = playtime
        )
    }

    fun unlockEnding(endingId: String) {
        val current = (prefs.getStringSet(KEY_ENDINGS, emptySet()) ?: emptySet()).toMutableSet()
        current.add(endingId)
        prefs.edit().putStringSet(KEY_ENDINGS, current).apply()
    }

    fun getUnlockedEndings(): Set<String> {
        return prefs.getStringSet(KEY_ENDINGS, emptySet()) ?: emptySet()
    }

    fun getHighestChapterUnlocked(): Int {
        return prefs.getInt(KEY_UNLOCKED_CHAPTER, 1)
    }

    fun setHighestChapterUnlocked(ch: Int) {
        val highest = maxOf(ch, getHighestChapterUnlocked())
        prefs.edit().putInt(KEY_UNLOCKED_CHAPTER, highest).apply()
    }

    fun resetGame() {
        val endings = getUnlockedEndings()
        val highest = getHighestChapterUnlocked()
        prefs.edit().clear().apply()
        // preserve endings unlocked & chapter select
        prefs.edit().putStringSet(KEY_ENDINGS, endings).putInt(KEY_UNLOCKED_CHAPTER, highest).apply()
    }

    companion object {
        private const val KEY_CHAPTER = "chapter"
        private const val KEY_PLAYER_HP = "player_hp"
        private const val KEY_PLAYER_SANITY = "player_sanity"
        private const val KEY_AMMO_CLIP = "ammo_clip"
        private const val KEY_AMMO_RESERVE = "ammo_reserve"
        private const val KEY_UNLOCKED_CHAPTER = "unlocked_chapter"
        private const val KEY_FOUND_NOTES = "found_notes"
        private const val KEY_FLAGS = "flags"
        private const val KEY_ENDINGS = "endings"
        private const val KEY_PLAYTIME = "playtime"
    }
}
