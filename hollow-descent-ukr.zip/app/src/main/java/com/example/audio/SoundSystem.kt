package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/**
 * High-performance procedural sound synthesizer using Android AudioTrack.
 * Generates retro 8/16-bit sound effects and Undertale-style speech blips
 * without requiring external sound files.
 */
class SoundSystem(private val context: Context) {
    private val sampleRate = 22050
    private val scope = CoroutineScope(Dispatchers.Default)

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    var isSoundEnabled: Boolean = true
    var isHapticsEnabled: Boolean = true

    fun playGunshot() {
        if (!isSoundEnabled) return
        scope.launch {
            val durationMs = 280
            val numSamples = (sampleRate * durationMs / 1000)
            val buffer = ShortArray(numSamples)
            val random = Random(42)

            for (i in 0 until numSamples) {
                val t = i.toFloat() / numSamples
                val envelope = exp(-t * 9.0).toFloat()
                // initial transient spike + low rumble
                val noise = (random.nextFloat() * 2f - 1f)
                val lowBoom = sin(2.0 * PI * 80.0 * (1.0 - t * 0.5) * (i.toDouble() / sampleRate)).toFloat()
                val sample = ((noise * 0.7f + lowBoom * 0.6f) * envelope * Short.MAX_VALUE * 0.9f)
                    .coerceIn(Short.MIN_VALUE.toFloat(), Short.MAX_VALUE.toFloat())
                buffer[i] = sample.toInt().toShort()
            }
            playRawPcm(buffer)
        }
        triggerVibration(60, 200)
    }

    fun playGunEmpty() {
        if (!isSoundEnabled) return
        scope.launch {
            val durationMs = 60
            val numSamples = (sampleRate * durationMs / 1000)
            val buffer = ShortArray(numSamples)
            for (i in 0 until numSamples) {
                val t = i.toFloat() / numSamples
                val envelope = exp(-t * 20.0).toFloat()
                val wave = sin(2.0 * PI * 1800.0 * (i.toDouble() / sampleRate)).toFloat()
                buffer[i] = (wave * envelope * Short.MAX_VALUE * 0.4f).toInt().toShort()
            }
            playRawPcm(buffer)
        }
    }

    fun playReload() {
        if (!isSoundEnabled) return
        scope.launch {
            val durationMs = 220
            val numSamples = (sampleRate * durationMs / 1000)
            val buffer = ShortArray(numSamples)
            val click1 = 30 * sampleRate / 1000
            val click2 = 120 * sampleRate / 1000
            for (i in 0 until numSamples) {
                var s = 0f
                if (i in click1 until click1 + 400) {
                    val progress = (i - click1).toFloat() / 400f
                    s += sin(2.0 * PI * 1200.0 * (i.toDouble() / sampleRate)).toFloat() * exp(-progress * 8f)
                }
                if (i in click2 until click2 + 500) {
                    val progress = (i - click2).toFloat() / 500f
                    s += sin(2.0 * PI * 950.0 * (i.toDouble() / sampleRate)).toFloat() * exp(-progress * 8f)
                }
                buffer[i] = (s * Short.MAX_VALUE * 0.5f).toInt().toShort()
            }
            playRawPcm(buffer)
        }
    }

    fun playBatSwing() {
        if (!isSoundEnabled) return
        scope.launch {
            val durationMs = 150
            val numSamples = (sampleRate * durationMs / 1000)
            val buffer = ShortArray(numSamples)
            val random = Random(13)
            for (i in 0 until numSamples) {
                val t = i.toFloat() / numSamples
                val envelope = sin(t * PI).toFloat()
                val freq = 450.0 - t * 250.0
                val sine = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)).toFloat()
                val noise = (random.nextFloat() * 2f - 1f) * 0.3f
                buffer[i] = ((sine * 0.7f + noise) * envelope * Short.MAX_VALUE * 0.5f).toInt().toShort()
            }
            playRawPcm(buffer)
        }
        triggerVibration(25, 80)
    }

    fun playBatHit() {
        if (!isSoundEnabled) return
        scope.launch {
            val durationMs = 200
            val numSamples = (sampleRate * durationMs / 1000)
            val buffer = ShortArray(numSamples)
            val random = Random(99)
            for (i in 0 until numSamples) {
                val t = i.toFloat() / numSamples
                val envelope = exp(-t * 12.0).toFloat()
                val punch = sin(2.0 * PI * 110.0 * (i.toDouble() / sampleRate)).toFloat()
                val crunch = (random.nextFloat() * 2f - 1f) * 0.8f
                val sample = ((punch * 0.6f + crunch * 0.6f) * envelope * Short.MAX_VALUE * 0.85f)
                    .coerceIn(Short.MIN_VALUE.toFloat(), Short.MAX_VALUE.toFloat())
                buffer[i] = sample.toInt().toShort()
            }
            playRawPcm(buffer)
        }
        triggerVibration(45, 180)
    }

    fun playPlayerHurt() {
        if (!isSoundEnabled) return
        scope.launch {
            val durationMs = 180
            val numSamples = (sampleRate * durationMs / 1000)
            val buffer = ShortArray(numSamples)
            for (i in 0 until numSamples) {
                val t = i.toFloat() / numSamples
                val envelope = exp(-t * 10.0).toFloat()
                val wave = sin(2.0 * PI * (140.0 - t * 60.0) * (i.toDouble() / sampleRate)).toFloat()
                buffer[i] = (wave * envelope * Short.MAX_VALUE * 0.8f).toInt().toShort()
            }
            playRawPcm(buffer)
        }
        triggerVibration(80, 255)
    }

    fun playMonsterRoar(chapter: Int) {
        if (!isSoundEnabled) return
        scope.launch {
            val durationMs = 350
            val numSamples = (sampleRate * durationMs / 1000)
            val buffer = ShortArray(numSamples)
            val baseFreq = when (chapter) {
                1 -> 90.0
                2 -> 70.0
                else -> 55.0
            }
            val random = Random(123)
            for (i in 0 until numSamples) {
                val t = i.toFloat() / numSamples
                val envelope = sin(t * PI).toFloat()
                val mod = sin(2.0 * PI * 22.0 * (i.toDouble() / sampleRate)).toFloat() * 25.0
                val carrier = sin(2.0 * PI * (baseFreq + mod) * (i.toDouble() / sampleRate)).toFloat()
                val noise = (random.nextFloat() * 2f - 1f) * 0.35f
                buffer[i] = ((carrier * 0.7f + noise) * envelope * Short.MAX_VALUE * 0.7f).toInt().toShort()
            }
            playRawPcm(buffer)
        }
    }

    fun playItemPickup() {
        if (!isSoundEnabled) return
        scope.launch {
            val durationMs = 220
            val numSamples = (sampleRate * durationMs / 1000)
            val buffer = ShortArray(numSamples)
            val chord = doubleArrayOf(523.25, 659.25, 783.99) // C5, E5, G5
            val step = numSamples / 3
            for (i in 0 until numSamples) {
                val noteIdx = (i / step).coerceAtMost(2)
                val noteOffset = i % step
                val noteT = noteOffset.toFloat() / step
                val envelope = exp(-noteT * 7.0).toFloat()
                val freq = chord[noteIdx]
                val wave = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)).toFloat()
                buffer[i] = (wave * envelope * Short.MAX_VALUE * 0.6f).toInt().toShort()
            }
            playRawPcm(buffer)
        }
    }

    fun playDialogueBlip(characterType: DialogueVoice) {
        if (!isSoundEnabled) return
        scope.launch {
            val durationMs = 38
            val numSamples = (sampleRate * durationMs / 1000)
            val buffer = ShortArray(numSamples)
            val (freq, timbre) = when (characterType) {
                DialogueVoice.FATHER -> 135.0 to 1
                DialogueVoice.LEO -> 380.0 to 0
                DialogueVoice.WOODCUTTER -> 85.0 to 2
                DialogueVoice.THE_VOID -> 65.0 to 2
                DialogueVoice.RADIO -> 720.0 to 0
                DialogueVoice.SYSTEM -> 260.0 to 0
            }
            for (i in 0 until numSamples) {
                val t = i.toFloat() / numSamples
                val envelope = sin(t * PI).toFloat()
                val wave = when (timbre) {
                    0 -> sin(2.0 * PI * freq * (i.toDouble() / sampleRate)).toFloat()
                    1 -> {
                        val s1 = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)).toFloat()
                        val s2 = sin(2.0 * PI * (freq * 2.0) * (i.toDouble() / sampleRate)).toFloat() * 0.4f
                        s1 + s2
                    }
                    else -> {
                        // square-ish / harsh
                        val phase = (i.toDouble() / sampleRate * freq) % 1.0
                        if (phase < 0.5) 0.8f else -0.8f
                    }
                }
                buffer[i] = (wave * envelope * Short.MAX_VALUE * 0.35f).toInt().toShort()
            }
            playRawPcm(buffer)
        }
    }

    fun playFlashlightClick() {
        if (!isSoundEnabled) return
        scope.launch {
            val durationMs = 35
            val numSamples = (sampleRate * durationMs / 1000)
            val buffer = ShortArray(numSamples)
            for (i in 0 until numSamples) {
                val t = i.toFloat() / numSamples
                val envelope = exp(-t * 22.0).toFloat()
                val wave = sin(2.0 * PI * 2200.0 * (i.toDouble() / sampleRate)).toFloat()
                buffer[i] = (wave * envelope * Short.MAX_VALUE * 0.4f).toInt().toShort()
            }
            playRawPcm(buffer)
        }
    }

    fun playPsychologicalDistortion() {
        if (!isSoundEnabled) return
        scope.launch {
            val durationMs = 400
            val numSamples = (sampleRate * durationMs / 1000)
            val buffer = ShortArray(numSamples)
            val random = Random(777)
            for (i in 0 until numSamples) {
                val t = i.toFloat() / numSamples
                val envelope = sin(t * PI).toFloat()
                val freq = 120.0 + sin(t * 18.0) * 80.0
                val sine = sin(2.0 * PI * freq * (i.toDouble() / sampleRate)).toFloat()
                val static = (random.nextFloat() * 2f - 1f) * 0.5f
                buffer[i] = ((sine * 0.5f + static) * envelope * Short.MAX_VALUE * 0.6f).toInt().toShort()
            }
            playRawPcm(buffer)
        }
        triggerVibration(120, 180)
    }

    private fun playRawPcm(samples: ShortArray) {
        try {
            val byteBuffer = ByteBuffer.allocate(samples.size * 2)
            byteBuffer.order(ByteOrder.LITTLE_ENDIAN)
            for (s in samples) {
                byteBuffer.putShort(s)
            }
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(byteBuffer.capacity())
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(byteBuffer.array(), 0, byteBuffer.capacity())
            audioTrack.play()
            // release after finished
            scope.launch {
                val sleepMs = (samples.size * 1000L / sampleRate) + 50L
                kotlinx.coroutines.delay(sleepMs)
                try {
                    audioTrack.stop()
                    audioTrack.release()
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            // gracefully ignore if device audio buffer unavailable
        }
    }

    private fun triggerVibration(durationMs: Long, amplitude: Int = 128) {
        if (!isHapticsEnabled || vibrator == null || !vibrator.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, amplitude.coerceIn(1, 255)))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }
}

enum class DialogueVoice {
    FATHER,
    LEO,
    WOODCUTTER,
    THE_VOID,
    RADIO,
    SYSTEM
}
