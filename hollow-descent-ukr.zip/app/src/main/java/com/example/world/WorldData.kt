package com.example.world

import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import com.example.model.*

data class Obstacle(
    val bounds: Rect,
    val type: ObstacleType,
    val color: Color = Color(0xFF2E3D29)
)

enum class ObstacleType {
    TREE,
    BOULDER,
    WALL,
    FENCE,
    VEHICLE,
    WATER,
    VOID_HOLE,
    FURNITURE
}

data class MapZone(
    val id: String,
    val name: String,
    val chapter: GameChapter,
    val width: Float,
    val height: Float,
    val obstacles: List<Obstacle>,
    val interactables: List<Interactable>,
    val initialMonsters: List<Monster>,
    val ambientColor: Color,
    val fogDensity: Float,
    val playerSpawn: Vector2
)

object WorldData {

    fun buildChapter1Map(): MapZone {
        val obstacles = mutableListOf<Obstacle>()
        val interactables = mutableListOf<Interactable>()
        val monsters = mutableListOf<Monster>()

        // Highway bounds (x: 0 to 1800, y: 0 to 2200)
        // Guardrails along top road
        obstacles.add(Obstacle(Rect(0f, 80f, 1800f, 100f), ObstacleType.FENCE, Color(0xFF555566)))
        obstacles.add(Obstacle(Rect(0f, 480f, 750f, 500f), ObstacleType.FENCE, Color(0xFF555566)))
        // Gap at 750..900 for descent into gorge
        obstacles.add(Obstacle(Rect(900f, 480f, 1800f, 500f), ObstacleType.FENCE, Color(0xFF555566)))

        // The Sedan (at x=400, y=280)
        obstacles.add(Obstacle(Rect(360f, 240f, 480f, 340f), ObstacleType.VEHICLE, Color(0xFF1E2836)))

        // Interactables on car
        interactables.add(
            Interactable(
                id = "car_glovebox",
                pos = Vector2(420f, 270f),
                radius = 55f,
                type = InteractableType.CAR_GLOVEBOX,
                name = "Бардачок",
                prompt = "Обшукати бардачок"
            )
        )
        interactables.add(
            Interactable(
                id = "car_trunk",
                pos = Vector2(360f, 290f),
                radius = 55f,
                type = InteractableType.CAR_TRUNK,
                name = "Багажник",
                prompt = "Відкрити багажник"
            )
        )
        interactables.add(
            Interactable(
                id = "broken_guardrail",
                pos = Vector2(825f, 490f),
                radius = 65f,
                type = InteractableType.CRAG_DESCENT_LEDGE,
                name = "Зламане відбійне огородження",
                prompt = "Спуститися в ущелину"
            )
        )

        // Mountain foothills and boulders below highway (y: 500 to 2200)
        // Forest trees along left border
        for (y in 550..2150 step 120) {
            obstacles.add(Obstacle(Rect(40f, y.toFloat(), 130f, (y + 90).toFloat()), ObstacleType.TREE, Color(0xFF152618)))
            obstacles.add(Obstacle(Rect(1680f, y.toFloat(), 1760f, (y + 90).toFloat()), ObstacleType.TREE, Color(0xFF152618)))
        }

        // Rocky path clusters
        obstacles.add(Obstacle(Rect(400f, 700f, 560f, 850f), ObstacleType.BOULDER, Color(0xFF3B4048)))
        obstacles.add(Obstacle(Rect(1100f, 680f, 1280f, 820f), ObstacleType.BOULDER, Color(0xFF3B4048)))
        obstacles.add(Obstacle(Rect(600f, 1050f, 750f, 1200f), ObstacleType.TREE, Color(0xFF182A1B)))
        obstacles.add(Obstacle(Rect(980f, 1100f, 1150f, 1250f), ObstacleType.TREE, Color(0xFF182A1B)))
        obstacles.add(Obstacle(Rect(320f, 1350f, 520f, 1500f), ObstacleType.BOULDER, Color(0xFF3B4048)))
        obstacles.add(Obstacle(Rect(1250f, 1380f, 1420f, 1540f), ObstacleType.TREE, Color(0xFF152618)))

        // Radio relay shed
        obstacles.add(Obstacle(Rect(800f, 1380f, 960f, 1480f), ObstacleType.WALL, Color(0xFF4A382C)))
        interactables.add(
            Interactable(
                id = "radio_shed_note",
                pos = Vector2(880f, 1500f),
                type = InteractableType.NOTE,
                name = "Журнал лісничого",
                prompt = "Прочитати попередження лісничого",
                description = "'Бійтеся плакучих тіней у тумані. Вони імітують дитячий плач, щоб заманити водіїв у провалля.'"
            )
        )
        interactables.add(
            Interactable(
                id = "ch1_ammo_1",
                pos = Vector2(830f, 1520f),
                type = InteractableType.AMMO_PICKUP,
                name = "Коробка куль .38",
                prompt = "Взяти кулі (+6)"
            )
        )
        interactables.add(
            Interactable(
                id = "ch1_medkit",
                pos = Vector2(930f, 1520f),
                type = InteractableType.MEDKIT_PICKUP,
                name = "Аптечка лісничого",
                prompt = "Взяти аптечку (+50 HP)"
            )
        )

        // Save lantern before gorge
        interactables.add(
            Interactable(
                id = "ch1_lantern",
                pos = Vector2(880f, 1720f),
                type = InteractableType.SAVE_LANTERN,
                name = "Гасова лампа",
                prompt = "Відпочити біля лампи (відновити розсудок)"
            )
        )

        // Monsters in outskirts
        monsters.add(
            Monster(
                id = "m1_1",
                category = MonsterCategory.MIST_WEEPER,
                name = "Плакуча примара туману",
                pos = Vector2(700f, 850f),
                hp = 60f,
                maxHp = 60f,
                speed = 125f,
                touchDamage = 14f,
                attackRange = 40f,
                aggroRadius = 260f
            )
        )
        monsters.add(
            Monster(
                id = "m1_2",
                category = MonsterCategory.MIST_WEEPER,
                name = "Плакуча примара туману",
                pos = Vector2(1050f, 950f),
                hp = 60f,
                maxHp = 60f,
                speed = 125f,
                touchDamage = 14f,
                attackRange = 40f,
                aggroRadius = 260f
            )
        )
        monsters.add(
            Monster(
                id = "m1_3",
                category = MonsterCategory.BRAMBLE_CRAWLER,
                name = "Тернистий повзун",
                pos = Vector2(500f, 1200f),
                hp = 45f,
                maxHp = 45f,
                speed = 90f,
                touchDamage = 12f,
                attackRange = 35f,
                aggroRadius = 230f
            )
        )
        monsters.add(
            Monster(
                id = "m1_4",
                category = MonsterCategory.BRAMBLE_CRAWLER,
                name = "Тернистий повзун",
                pos = Vector2(1200f, 1250f),
                hp = 45f,
                maxHp = 45f,
                speed = 90f,
                touchDamage = 12f,
                attackRange = 35f,
                aggroRadius = 230f
            )
        )

        // Boss in clearing (at y=1980)
        monsters.add(
            Monster(
                id = "boss_ch1",
                category = MonsterCategory.GORGE_ECHO_BOSS,
                name = "Відлуння ущелини",
                pos = Vector2(880f, 1980f),
                hp = 380f,
                maxHp = 380f,
                speed = 100f,
                touchDamage = 22f,
                attackRange = 55f,
                aggroRadius = 280f
            )
        )

        return MapZone(
            id = "chapter_1_map",
            name = "Гірський перевал Блеквуд і передгір'я",
            chapter = GameChapter.CHAPTER_1,
            width = 1800f,
            height = 2200f,
            obstacles = obstacles,
            interactables = interactables,
            initialMonsters = monsters,
            ambientColor = Color(0xFF070B10),
            fogDensity = 0.88f,
            playerSpawn = Vector2(430f, 320f)
        )
    }

    fun buildChapter2Map(): MapZone {
        val obstacles = mutableListOf<Obstacle>()
        val interactables = mutableListOf<Interactable>()
        val monsters = mutableListOf<Monster>()

        // Sprawling labyrinthine forest & sawmill (x: 0 to 2400, y: 0 to 2400)
        // Outer boundaries
        obstacles.add(Obstacle(Rect(0f, 0f, 2400f, 60f), ObstacleType.WALL, Color(0xFF0F1A12)))
        obstacles.add(Obstacle(Rect(0f, 2340f, 2400f, 2400f), ObstacleType.WALL, Color(0xFF0F1A12)))
        obstacles.add(Obstacle(Rect(0f, 0f, 60f, 2400f), ObstacleType.WALL, Color(0xFF0F1A12)))
        obstacles.add(Obstacle(Rect(2340f, 0f, 2400f, 2400f), ObstacleType.WALL, Color(0xFF0F1A12)))

        // Thick forest maze trees
        val mazeTreeCoords = listOf(
            200f to 300f, 350f to 300f, 500f to 300f,
            300f to 600f, 300f to 750f, 300f to 900f,
            700f to 500f, 850f to 500f, 1000f to 500f,
            600f to 900f, 750f to 900f, 900f to 900f,
            1200f to 350f, 1200f to 500f, 1200f to 650f,
            1500f to 700f, 1650f to 700f, 1800f to 700f,
            1600f to 950f, 1600f to 1100f, 1600f to 1250f
        )
        for ((tx, ty) in mazeTreeCoords) {
            obstacles.add(Obstacle(Rect(tx, ty, tx + 90f, ty + 120f), ObstacleType.TREE, Color(0xFF132317)))
        }

        // Ancient Sawmill Complex (Center: x=900 to 1500, y=1400 to 2100)
        // Sawmill outer fence
        obstacles.add(Obstacle(Rect(850f, 1400f, 1100f, 1430f), ObstacleType.FENCE, Color(0xFF3E2F23)))
        obstacles.add(Obstacle(Rect(1250f, 1400f, 1550f, 1430f), ObstacleType.FENCE, Color(0xFF3E2F23)))
        obstacles.add(Obstacle(Rect(850f, 1400f, 880f, 2100f), ObstacleType.WALL, Color(0xFF3E2F23)))
        obstacles.add(Obstacle(Rect(1520f, 1400f, 1550f, 2100f), ObstacleType.WALL, Color(0xFF3E2F23)))

        // Sawmill Estate Gate (locked at x=1100..1250, y=1400..1430)
        obstacles.add(Obstacle(Rect(1100f, 1400f, 1250f, 1430f), ObstacleType.FENCE, Color(0xFF886644)))

        // Estate Building Interior Walls
        obstacles.add(Obstacle(Rect(950f, 1750f, 1450f, 1780f), ObstacleType.WALL, Color(0xFF4A3525)))
        obstacles.add(Obstacle(Rect(1180f, 1780f, 1210f, 2050f), ObstacleType.WALL, Color(0xFF4A3525)))

        // Key Items & Puzzles
        // 3 Fuses hidden across the forest map
        interactables.add(
            Interactable(
                id = "fuse_1",
                pos = Vector2(400f, 400f),
                type = InteractableType.KEY_ITEM,
                name = "Керамічний запобіжник A",
                prompt = "Взяти запобіжник A (інструментальний сарай)"
            )
        )
        interactables.add(
            Interactable(
                id = "fuse_2",
                pos = Vector2(1900f, 500f),
                type = InteractableType.KEY_ITEM,
                name = "Керамічний запобіжник B",
                prompt = "Взяти запобіжник B (соснова вівтарна)"
            )
        )
        interactables.add(
            Interactable(
                id = "fuse_3",
                pos = Vector2(700f, 1200f),
                type = InteractableType.KEY_ITEM,
                name = "Керамічний запобіжник C",
                prompt = "Взяти запобіжник C (старий колодязь)"
            )
        )

        // Generator Switch at the sawmill fence
        interactables.add(
            Interactable(
                id = "sawmill_generator",
                pos = Vector2(1070f, 1370f),
                type = InteractableType.GENERATOR_SWITCH,
                name = "Дизельний генератор лісопилки",
                prompt = "Вставити запобіжники та запустити генератор"
            )
        )

        // Lore Notes
        interactables.add(
            Interactable(
                id = "ch2_note_1",
                pos = Vector2(480f, 850f),
                type = InteractableType.NOTE,
                name = "Щоденник лісника",
                prompt = "Прочитати закривавлену сторінку"
            )
        )
        interactables.add(
            Interactable(
                id = "ch2_note_2",
                pos = Vector2(1350f, 1950f),
                type = InteractableType.NOTE,
                name = "Поліцейський протокол ДТП",
                prompt = "Оглянути висновок коронера"
            )
        )

        // Supplies
        interactables.add(
            Interactable(
                id = "ch2_ammo_1",
                pos = Vector2(1850f, 1100f),
                type = InteractableType.AMMO_PICKUP,
                name = "Схованка мисливця",
                prompt = "Забрати набої (+6)"
            )
        )
        interactables.add(
            Interactable(
                id = "ch2_meds",
                pos = Vector2(1020f, 1900f),
                type = InteractableType.SANITY_MEDS,
                name = "Флакон заспокійливого",
                prompt = "Прийняти заспокійливе (+60 розсудку)"
            )
        )

        // Safe Lantern in Sawmill Courtyard
        interactables.add(
            Interactable(
                id = "ch2_lantern",
                pos = Vector2(1180f, 1550f),
                type = InteractableType.SAVE_LANTERN,
                name = "Лампа лісопилки",
                prompt = "Відпочити біля лампи"
            )
        )

        // Monsters in Chapter 2
        monsters.add(
            Monster(
                id = "m2_1",
                category = MonsterCategory.TIMBER_LURKER,
                name = "Деревний причаєний",
                pos = Vector2(650f, 650f),
                hp = 95f,
                maxHp = 95f,
                speed = 85f,
                touchDamage = 18f,
                attackRange = 45f,
                aggroRadius = 240f
            )
        )
        monsters.add(
            Monster(
                id = "m2_2",
                category = MonsterCategory.LANTERN_GHOUL,
                name = "Ліхтарний упир",
                pos = Vector2(1500f, 450f),
                hp = 75f,
                maxHp = 75f,
                speed = 135f,
                touchDamage = 16f,
                attackRange = 40f,
                aggroRadius = 310f
            )
        )
        monsters.add(
            Monster(
                id = "m2_3",
                category = MonsterCategory.TIMBER_LURKER,
                name = "Деревний причаєний",
                pos = Vector2(1750f, 950f),
                hp = 95f,
                maxHp = 95f,
                speed = 85f,
                touchDamage = 18f,
                attackRange = 45f,
                aggroRadius = 240f
            )
        )
        monsters.add(
            Monster(
                id = "m2_4",
                category = MonsterCategory.LANTERN_GHOUL,
                name = "Ліхтарний упир",
                pos = Vector2(900f, 1050f),
                hp = 75f,
                maxHp = 75f,
                speed = 135f,
                touchDamage = 16f,
                attackRange = 40f,
                aggroRadius = 310f
            )
        )

        // Boss in Sawmill Workshop (at x=1350, y=1900)
        monsters.add(
            Monster(
                id = "boss_ch2",
                category = MonsterCategory.CORRUPTED_WOODCUTTER_BOSS,
                name = "Осквернений лісоруб",
                pos = Vector2(1320f, 1920f),
                hp = 620f,
                maxHp = 620f,
                speed = 92f,
                touchDamage = 26f,
                attackRange = 65f,
                aggroRadius = 300f
            )
        )

        return MapZone(
            id = "chapter_2_map",
            name = "Лабіринтний ліс і лісопилка",
            chapter = GameChapter.CHAPTER_2,
            width = 2400f,
            height = 2400f,
            obstacles = obstacles,
            interactables = interactables,
            initialMonsters = monsters,
            ambientColor = Color(0xFF040A06),
            fogDensity = 0.92f,
            playerSpawn = Vector2(1200f, 180f)
        )
    }

    fun buildChapter3Map(): MapZone {
        val obstacles = mutableListOf<Obstacle>()
        val interactables = mutableListOf<Interactable>()
        val monsters = mutableListOf<Monster>()

        // Surreal Distortion Reality Void (x: 0 to 2200, y: 0 to 2200)
        // Floating asphalt islands separated by void gaps
        // Void perimeter
        obstacles.add(Obstacle(Rect(0f, 0f, 2200f, 80f), ObstacleType.VOID_HOLE, Color(0xFF280735)))
        obstacles.add(Obstacle(Rect(0f, 2120f, 2200f, 2200f), ObstacleType.VOID_HOLE, Color(0xFF280735)))
        obstacles.add(Obstacle(Rect(0f, 0f, 80f, 2200f), ObstacleType.VOID_HOLE, Color(0xFF280735)))
        obstacles.add(Obstacle(Rect(2120f, 0f, 2200f, 2200f), ObstacleType.VOID_HOLE, Color(0xFF280735)))

        // Floating highway barriers and distorted wreckage
        obstacles.add(Obstacle(Rect(400f, 350f, 650f, 400f), ObstacleType.WALL, Color(0xFF5D1049)))
        obstacles.add(Obstacle(Rect(1450f, 350f, 1700f, 400f), ObstacleType.WALL, Color(0xFF5D1049)))
        obstacles.add(Obstacle(Rect(800f, 650f, 920f, 900f), ObstacleType.WALL, Color(0xFF3E0A52)))
        obstacles.add(Obstacle(Rect(1200f, 650f, 1320f, 900f), ObstacleType.WALL, Color(0xFF3E0A52)))

        // Frozen suspended car in the void (x=1050, y=750)
        obstacles.add(Obstacle(Rect(1000f, 700f, 1140f, 820f), ObstacleType.VEHICLE, Color(0xFF880E4F)))

        // Distorted hospital beds / mirrors
        obstacles.add(Obstacle(Rect(500f, 1150f, 650f, 1250f), ObstacleType.FURNITURE, Color(0xFFB0BEC5)))
        obstacles.add(Obstacle(Rect(1500f, 1150f, 1650f, 1250f), ObstacleType.FURNITURE, Color(0xFFB0BEC5)))

        // Interactables
        interactables.add(
            Interactable(
                id = "frozen_car_clue",
                pos = Vector2(1070f, 850f),
                type = InteractableType.NOTE,
                name = "Завислі рештки седана",
                prompt = "Оглянути рештки аварії",
                description = "Лобове скло розбите зсередини. На панелі лежить червоний іграшковий седан Лео. Одометр зупинився на 02:14."
            )
        )
        interactables.add(
            Interactable(
                id = "leo_drawing_clue",
                pos = Vector2(580f, 1300f),
                type = InteractableType.KEY_ITEM,
                name = "Малюнок олівцями",
                prompt = "Взяти малюнок Лео",
                description = "Малюнок: Артур, Лео та їхній пес під яскраво-жовтим сонцем. Дитячими літерами написано: 'НАЙКРАЩИЙ ТАТО'."
            )
        )
        interactables.add(
            Interactable(
                id = "ch3_ammo_1",
                pos = Vector2(1580f, 1300f),
                type = InteractableType.AMMO_PICKUP,
                name = "Срібні револьверні кулі",
                prompt = "Взяти чисті кулі (+12)"
            )
        )
        interactables.add(
            Interactable(
                id = "ch3_lantern",
                pos = Vector2(1070f, 1350f),
                type = InteractableType.SAVE_LANTERN,
                name = "Стовп світла",
                prompt = "Налаштуватися на спогад (повне лікування)"
            )
        )

        // Monsters in Chapter 3
        monsters.add(
            Monster(
                id = "m3_1",
                category = MonsterCategory.STATIC_PHANTOM,
                name = "Статичний фантом",
                pos = Vector2(750f, 500f),
                hp = 130f,
                maxHp = 130f,
                speed = 140f,
                touchDamage = 20f,
                attackRange = 45f,
                aggroRadius = 320f
            )
        )
        monsters.add(
            Monster(
                id = "m3_2",
                category = MonsterCategory.STATIC_PHANTOM,
                name = "Статичний фантом",
                pos = Vector2(1380f, 500f),
                hp = 130f,
                maxHp = 130f,
                speed = 140f,
                touchDamage = 20f,
                attackRange = 45f,
                aggroRadius = 320f
            )
        )
        monsters.add(
            Monster(
                id = "m3_3",
                category = MonsterCategory.GUILT_WEAVER,
                name = "Шпиль ткача провини",
                pos = Vector2(620f, 1000f),
                hp = 160f,
                maxHp = 160f,
                speed = 40f,
                touchDamage = 22f,
                attackRange = 220f,
                aggroRadius = 380f
            )
        )
        monsters.add(
            Monster(
                id = "m3_4",
                category = MonsterCategory.GUILT_WEAVER,
                name = "Шпиль ткача провини",
                pos = Vector2(1480f, 1000f),
                hp = 160f,
                maxHp = 160f,
                speed = 40f,
                touchDamage = 22f,
                attackRange = 220f,
                aggroRadius = 380f
            )
        )

        // Final Boss: The Void / The Manifest Guilt (at x=1070, y=1800)
        monsters.add(
            Monster(
                id = "boss_ch3",
                category = MonsterCategory.THE_VOID_BOSS,
                name = "Непрощена порожнеча",
                pos = Vector2(1070f, 1800f),
                hp = 880f,
                maxHp = 880f,
                speed = 88f,
                touchDamage = 30f,
                attackRange = 75f,
                aggroRadius = 450f
            )
        )

        return MapZone(
            id = "chapter_3_map",
            name = "Сюрреалістичне спотворення провини",
            chapter = GameChapter.CHAPTER_3,
            width = 2200f,
            height = 2200f,
            obstacles = obstacles,
            interactables = interactables,
            initialMonsters = monsters,
            ambientColor = Color(0xFF1A0522),
            fogDensity = 0.82f,
            playerSpawn = Vector2(1070f, 200f)
        )
    }
}
