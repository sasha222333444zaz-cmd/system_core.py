package com.example.ui.menu

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.engine.GameEngine
import com.example.model.InventoryItem
import com.example.model.ItemCategory
import com.example.model.WeaponType

enum class JournalTab {
    INVENTORY,
    WEAPONS,
    NOTES,
    ENDINGS
}

@Composable
fun InventoryJournalDialog(
    engine: GameEngine,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(JournalTab.INVENTORY) }
    var selectedItem by remember { mutableStateOf<InventoryItem?>(engine.inventory.firstOrNull()) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xE605080E))
                .padding(16.dp)
                .testTag("inventory_journal_dialog"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.9f)
                    .background(Color(0xFF0F141C), RoundedCornerShape(12.dp))
                    .border(2.dp, Color(0xFF64B5F6), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ЖУРНАЛ І ЩОДЕННИК ВИЖИВАННЯ",
                        color = Color(0xFFFFD54F),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_journal_button")) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Закрити",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tabs Navigation
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    JournalTab.values().forEach { tab ->
                        val isSelected = tab == selectedTab
                        Button(
                            onClick = { selectedTab = tab },
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("tab_${tab.name.lowercase()}"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) Color(0xFF1976D2) else Color(0xFF263238),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = when (tab) { JournalTab.INVENTORY -> "ІНВЕНТАР"; JournalTab.WEAPONS -> "ЗБРОЯ"; JournalTab.NOTES -> "НОТАТКИ"; JournalTab.ENDINGS -> "ФІНАЛИ" },
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Content View according to selected Tab
                when (selectedTab) {
                    JournalTab.INVENTORY -> {
                        InventoryView(
                            items = engine.inventory,
                            selectedItem = selectedItem,
                            onSelectItem = { selectedItem = it }
                        )
                    }

                    JournalTab.WEAPONS -> {
                        WeaponsView(engine = engine)
                    }

                    JournalTab.NOTES -> {
                        NotesView(collectedNotes = engine.collectedNotes)
                    }

                    JournalTab.ENDINGS -> {
                        EndingsProgressView(engine = engine)
                    }
                }
            }
        }
    }
}

@Composable
fun InventoryView(
    items: List<InventoryItem>,
    selectedItem: InventoryItem?,
    onSelectItem: (InventoryItem) -> Unit
) {
    if (items.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                text = "Інвентар порожній.",
                color = Color.Gray,
                fontFamily = FontFamily.Monospace
            )
        }
        return
    }

    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Items List Column
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(items) { item ->
                val isSelected = item.id == selectedItem?.id
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) Color(0xFF1E3A5F) else Color(0xFF1A212B))
                        .border(
                            1.dp,
                            if (isSelected) Color(0xFFFFD54F) else Color(0x33FFFFFF),
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectItem(item) }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = item.name,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "x${item.count}",
                        color = Color(0xFFFFD54F),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Selected Item Details Column
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(Color(0xFF121820), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0x44FFFFFF), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            if (selectedItem != null) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = selectedItem.name.uppercase(),
                        color = Color(0xFFFFD54F),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Категорія: ${when (selectedItem.category) { ItemCategory.WEAPON -> "Зброя"; ItemCategory.AMMO -> "Набої"; ItemCategory.MEDICAL -> "Медицина"; ItemCategory.KEY -> "Ключовий предмет"; ItemCategory.LORE -> "Історія" }}",
                        color = Color(0xFF90CAF9),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Divider(color = Color(0x33FFFFFF))
                    Text(
                        text = selectedItem.description,
                        color = Color(0xFFCFD8DC),
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun WeaponsView(engine: GameEngine) {
    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Weapon 1: Revolver
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A212B)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE53935))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = WeaponType.REVOLVER.displayName,
                            color = Color(0xFFFFD54F),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${engine.revolverAmmoClip}/${engine.revolverReserveAmmo}",
                            color = Color(0xFFFF5252),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = WeaponType.REVOLVER.description,
                        color = Color(0xFFB0BEC5),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "Шкода: 85 | Дальність: 600 м | Набої: .38 (підібрані)",
                    color = Color(0xFF81C784),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Weapon 2: Baseball Bat
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A212B)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF8D6E63))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = WeaponType.BASEBALL_BAT.displayName,
                            color = Color(0xFFFFD54F),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "БЕЗЛІМІТ",
                            color = Color(0xFF81C784),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = WeaponType.BASEBALL_BAT.description,
                        color = Color(0xFFB0BEC5),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "Шкода: 45 | Дуга: 110° | Відкидання: важке оглушення",
                    color = Color(0xFF81C784),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun NotesView(collectedNotes: Set<String>) {
    val noteEntries = listOf(
        "radio_shed_note" to ("Попередження лісничого" to "Плакучі тіні в тумані імітують дитячий плач, щоб заманити водіїв зі шляху в провалля."),
        "ch2_note_1" to ("Закривавлений журнал лісоруба" to "'Туман говорить голосами тих, кого ми втратили. Моя сокира — єдина зброя, що змушує плач замовкнути.'"),
        "ch2_note_2" to ("Офіційний поліцейський звіт про ДТП" to "'Зіткнення на трасі 9 біля 14-ї милі. Водій — Артур Венс. Дитину констатовано на місці.'"),
        "frozen_car_clue" to ("Підказка з панелі приладів" to "Спідометр завмер на 54 милях на годину. Іграшковий седан Лео лежить біля тріснутого лобового скла.")
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(noteEntries) { (id, pair) ->
            val isUnlocked = collectedNotes.contains(id)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (isUnlocked) Color(0xFF1E2836) else Color(0xFF141920)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isUnlocked) Color(0xFF4FC3F7) else Color(0x22FFFFFF)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = if (isUnlocked) pair.first else "[ЗАСЕКРЕЧЕНИЙ ФАЙЛ — НЕ ЗНАЙДЕНО]",
                        color = if (isUnlocked) Color(0xFFFFD54F) else Color.Gray,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isUnlocked) pair.second else "Дослідіть відповідні зони розділу, щоб відкрити цей фрагмент психологічної головоломки.",
                        color = if (isUnlocked) Color.White else Color.DarkGray,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun EndingsProgressView(engine: GameEngine) {
    val endings = listOf(
        "ENDING_A" to ("Фінал A: Світанок прийняття" to "Прийміть правду про аварію, пробачте собі й дозвольте Лео спочивати з миром."),
        "ENDING_B" to ("Фінал B: Безкінечні пошуки" to "Відмовтеся бачити уламки й назавжди блукайте туманним лабіринтом."),
        "ENDING_C" to ("Фінал C: Петля пам'яті" to "Вистріліть у порожнечу кошмару, щоб прокинутися на початку поїздки.")
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "ПСИХОЛОГІЧНІ РОЗВ'ЯЗКИ",
            color = Color(0xFFFFD54F),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )

        endings.forEach { (code, pair) ->
            val unlocked = engine.storyFlags.contains(code)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (unlocked) Color(0xFF2E1C38) else Color(0xFF141920)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (unlocked) Color(0xFFCE93D8) else Color(0x22FFFFFF)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = pair.first,
                        color = if (unlocked) Color(0xFFE040FB) else Color.Gray,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (unlocked) pair.second else "Переможіть фінального психологічного боса в розділі III, щоб відкрити цей фінал.",
                        color = if (unlocked) Color.White else Color.DarkGray,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
