package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import com.example.engine.GameEngine
import com.example.ui.controls.ActionControls
import com.example.ui.controls.VirtualJoystick
import com.example.ui.dialogue.DialogueOverlay
import com.example.ui.hud.HUDOverlay
import com.example.ui.menu.EndingScreen
import com.example.ui.menu.GameOverScreen
import com.example.ui.menu.InventoryJournalDialog
import com.example.ui.render.GameRenderer
import kotlinx.coroutines.isActive

@Composable
fun GameScreen(
    engine: GameEngine,
    onReturnToMainMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showJournal by remember { mutableStateOf(false) }
    val textMeasurer = rememberTextMeasurer()

    // 60 FPS Game Loop
    LaunchedEffect(engine) {
        var lastTimeNanos = System.nanoTime()
        while (isActive) {
            withFrameNanos { nowNanos ->
                val dt = (nowNanos - lastTimeNanos) / 1_000_000_000f
                lastTimeNanos = nowNanos
                engine.update(dt)
            }
        }
    }

    // Trigger UI recomposition on tick
    val tick by engine.uiStateTick.collectAsState()

    // Android Back button handler
    BackHandler {
        if (showJournal) {
            showJournal = false
        } else if (engine.activeDialogue != null) {
            engine.onAdvanceDialogue()
        } else {
            engine.saveGameState()
            onReturnToMainMenu()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("game_screen")
    ) {
        // Suppress unused warning on tick by reading it
        @Suppress("UNUSED_VARIABLE")
        val currentTick = tick

        // 1. Primary Game Canvas (60 FPS Pixel Art Renderer)
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("game_canvas")
        ) {
            GameRenderer.render(
                scope = this,
                engine = engine,
                screenSize = size,
                textMeasurer = textMeasurer
            )
        }

        // 2. HUD Overlay (Health, Sanity, Objective, Journal Button)
        HUDOverlay(
            engine = engine,
            onOpenJournal = { showJournal = true },
            modifier = Modifier.align(Alignment.TopCenter)
        )

        // 3. Virtual Touch Controls (Joystick on left, Actions on right)
        // Only active when not blocked by dialogue choices or game over
        val controlsEnabled = engine.activeDialogue == null || engine.activeDialogue?.choices?.isEmpty() == true
        if (controlsEnabled && !engine.isGameOver && engine.activeEnding == null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 16.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                // Left: Virtual On-Screen Joystick
                VirtualJoystick(
                    modifier = Modifier.padding(start = 8.dp, bottom = 8.dp),
                    onMove = { dir -> engine.movementInput = dir }
                )

                // Right: Action Buttons (Bat, Revolver, Reload, Interact, Flashlight)
                ActionControls(
                    engine = engine,
                    modifier = Modifier.padding(end = 8.dp, bottom = 4.dp)
                )
            }
        }

        // 4. Undertale / Deltarune Dialogue Overlay
        val activeNode = engine.activeDialogue
        if (activeNode != null) {
            DialogueOverlay(
                engine = engine,
                node = activeNode,
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 10.dp)
            )
        }

        // 5. Modals & Screens: Journal, Game Over, Endings
        if (showJournal) {
            InventoryJournalDialog(
                engine = engine,
                onDismiss = { showJournal = false }
            )
        }

        if (engine.isGameOver) {
            GameOverScreen(
                onRetry = { engine.restartCurrentChapter() },
                onReturnToMenu = onReturnToMainMenu
            )
        }

        val ending = engine.activeEnding
        if (ending != null) {
            EndingScreen(
                ending = ending,
                onReturnToMenu = onReturnToMainMenu,
                onRestartChapter = { engine.restartCurrentChapter() }
            )
        }
    }
}
