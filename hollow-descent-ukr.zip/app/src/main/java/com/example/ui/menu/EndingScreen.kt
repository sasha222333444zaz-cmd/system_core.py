package com.example.ui.menu

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EndingType

@Composable
fun EndingScreen(
    ending: EndingType,
    onReturnToMenu: () -> Unit,
    onRestartChapter: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xF00A0310))
            .padding(16.dp)
            .testTag("ending_screen"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.88f)
                .background(Color(0xFF13081E), RoundedCornerShape(12.dp))
                .border(2.dp, Color(0xFFE040FB), RoundedCornerShape(12.dp))
                .padding(20.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Atmospheric ending art canvas
            Canvas(
                modifier = Modifier
                    .weight(0.9f)
                    .fillMaxHeight()
            ) {
                val w = size.width
                val h = size.height

                when (ending) {
                    EndingType.ACCEPTANCE -> {
                        // Rising morning sun breaking over mountain pines
                        drawCircle(color = Color(0xFFFFD54F), radius = 45f, center = Offset(w / 2f, h * 0.5f))
                        for (i in 0..10) {
                            val px = (w / 10f) * i
                            drawLine(color = Color(0xFF1B5E20), start = Offset(px, h), end = Offset(px, h * 0.4f), strokeWidth = 14f)
                        }
                    }
                    EndingType.DENIAL -> {
                        // Dark misty pines with weeping white dots
                        for (i in 0..8) {
                            val px = (w / 8f) * i
                            drawLine(color = Color(0xFF0F151B), start = Offset(px, h), end = Offset(px, h * 0.2f), strokeWidth = 18f)
                        }
                        drawCircle(color = Color.White, radius = 5f, center = Offset(w * 0.45f, h * 0.4f))
                        drawCircle(color = Color.White, radius = 5f, center = Offset(w * 0.55f, h * 0.4f))
                    }
                    EndingType.CYCLE -> {
                        // Ominous car headlights in thick fog
                        drawCircle(color = Color(0xFFFFEE58), radius = 24f, center = Offset(w * 0.4f, h * 0.5f))
                        drawCircle(color = Color(0xFFFFEE58), radius = 24f, center = Offset(w * 0.6f, h * 0.5f))
                    }
                }
            }

            // Right: Narrative Text and Choices
            Column(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.Start
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = ending.title,
                        color = Color(0xFFFFD54F),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Text(
                        text = ending.description,
                        color = Color(0xFFECEFF1),
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onRestartChapter,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("ending_replay_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF37474F)),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("ЗНОВУ", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Button(
                        onClick = onReturnToMenu,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("ending_menu_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7B1FA2)),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("ГОЛОВНЕ МЕНЮ", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun GameOverScreen(
    onRetry: () -> Unit,
    onReturnToMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xF5100000))
            .padding(16.dp)
            .testTag("game_over_screen"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .background(Color(0xFF1F0808), RoundedCornerShape(12.dp))
                .border(2.dp, Color(0xFFFF1744), RoundedCornerShape(12.dp))
                .padding(20.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Ominous skull canvas
            Canvas(
                modifier = Modifier
                    .weight(0.8f)
                    .fillMaxHeight()
            ) {
                val w = size.width
                val h = size.height
                drawCircle(color = Color(0xFF3E0A0A), radius = 55f, center = Offset(w / 2f, h / 2f))
                drawCircle(color = Color(0xFFFF1744), radius = 10f, center = Offset(w * 0.42f, h * 0.45f))
                drawCircle(color = Color(0xFFFF1744), radius = 10f, center = Offset(w * 0.58f, h * 0.45f))
            }

            // Right: Text & Actions
            Column(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.Start
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "ТВІЙ РОЗСУДОК РОЗСИПАВСЯ",
                        color = Color(0xFFFF1744),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )

                    Text(
                        text = "Темрява поглинула кроки Артура. Голос, що кликав із передгір'я, розчинився в нескінченному гірському тумані.",
                        color = Color(0xFFB0BEC5),
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onRetry,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("game_over_retry_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C)),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("СПРОБУВАТИ ЗНОВУ", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Button(
                        onClick = onReturnToMenu,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("game_over_menu_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF263238)),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("МЕНЮ", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
