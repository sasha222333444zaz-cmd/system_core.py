package com.example.ui.render

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.engine.GameEngine
import com.example.model.*
import com.example.world.Obstacle
import com.example.world.ObstacleType
import kotlin.math.*

object GameRenderer {

    fun render(
        scope: DrawScope,
        engine: GameEngine,
        screenSize: Size,
        textMeasurer: TextMeasurer
    ) {
        with(scope) {
            val cameraOffset = calculateCameraOffset(engine.playerPos, screenSize, engine.currentMap.width, engine.currentMap.height)
            // Apply screen shake
            val shakeX = if (engine.screenShakeAmount > 0f) (kotlin.random.Random.nextFloat() * 2f - 1f) * engine.screenShakeAmount else 0f
            val shakeY = if (engine.screenShakeAmount > 0f) (kotlin.random.Random.nextFloat() * 2f - 1f) * engine.screenShakeAmount else 0f
            val viewOffset = cameraOffset + Offset(shakeX, shakeY)

            // 1. Draw Ground Base
            drawGround(this, engine.currentChapter, viewOffset, engine.currentMap.width, engine.currentMap.height)

            // 2. Draw Obstacles & Environment
            for (obs in engine.currentMap.obstacles) {
                drawObstacle(this, obs, viewOffset, engine.currentChapter)
            }

            // 3. Draw Interactables
            for (item in engine.currentMap.interactables) {
                if (!item.isCollected) {
                    drawInteractable(this, item, viewOffset, engine)
                }
            }

            // 4. Draw Blood & Particles
            for (part in engine.particles) {
                val screenPos = Offset(part.pos.x - viewOffset.x, part.pos.y - viewOffset.y)
                drawCircle(
                    color = part.color.copy(alpha = (part.life / part.maxLife).coerceIn(0f, 1f)),
                    radius = part.size,
                    center = screenPos
                )
            }

            // 5. Draw Monsters
            for (m in engine.monsters) {
                drawMonster(this, m, viewOffset, textMeasurer)
            }

            // 6. Draw Player
            drawPlayer(this, engine, viewOffset)

            // 7. Draw Projectiles
            for (p in engine.projectiles) {
                val screenPos = Offset(p.pos.x - viewOffset.x, p.pos.y - viewOffset.y)
                drawCircle(
                    color = p.color,
                    radius = p.radius,
                    center = screenPos
                )
                // Tracer trail
                drawLine(
                    color = p.color.copy(alpha = 0.5f),
                    start = screenPos - Offset(p.velocity.x * 0.03f, p.velocity.y * 0.03f),
                    end = screenPos,
                    strokeWidth = p.radius * 1.5f
                )
            }

            // 8. Darkness & Fog of War with Dynamic Lights
            drawDarknessFog(this, engine, viewOffset, screenSize)

            // 9. Floating Combat Texts
            for (txt in engine.floatingTexts) {
                val screenPos = Offset(txt.pos.x - viewOffset.x, txt.pos.y - viewOffset.y)
                val alpha = (txt.life / txt.maxLife).coerceIn(0f, 1f)
                drawText(
                    textMeasurer = textMeasurer,
                    text = txt.text,
                    topLeft = screenPos,
                    style = TextStyle.Default.copy(
                        color = txt.color.copy(alpha = alpha),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                )
            }

            // 10. Psychological Blink / Distortions
            if (engine.screenBlinkAlpha > 0f) {
                drawRect(
                    color = Color.White.copy(alpha = engine.screenBlinkAlpha.coerceIn(0f, 1f)),
                    size = screenSize
                )
            }

            if (engine.playerSanity < 35f) {
                // Low sanity eerie red vignette
                val insanityPulse = (sin(engine.playerSanity * 0.2f) * 0.15f + 0.25f).coerceIn(0.1f, 0.45f)
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(Color.Transparent, Color(0x66FF0000).copy(alpha = insanityPulse)),
                        center = Offset(screenSize.width / 2f, screenSize.height / 2f),
                        radius = screenSize.width * 0.7f
                    ),
                    size = screenSize
                )
            }

            // 11. Cinematic Weather & Atmospheric Overlay
            drawAtmosphericWeather(this, engine.currentChapter, screenSize)
        }
    }

    private fun drawAtmosphericWeather(scope: DrawScope, chapter: GameChapter, screenSize: Size) {
        with(scope) {
            val time = System.currentTimeMillis() % 100000L
            if (chapter == GameChapter.CHAPTER_1 || chapter == GameChapter.CHAPTER_2) {
                // Atmospheric misty rain streaks
                val rainColor = Color(0x33B0BEC5)
                val rainSpeed = 700f
                for (i in 0..45) {
                    val rx = ((i * 47 + time * 0.15f) % (screenSize.width + 100f)) - 50f
                    val ry = ((i * 73 + time * 0.85f) % (screenSize.height + 100f)) - 50f
                    drawLine(
                        color = rainColor,
                        start = Offset(rx.toFloat(), ry.toFloat()),
                        end = Offset((rx + 12f).toFloat(), (ry + 26f).toFloat()),
                        strokeWidth = 1.5f
                    )
                }
            } else {
                // Chapter 3 Reality Glitch Scanlines & Void Shimmer
                for (y in 0..screenSize.height.toInt() step 8) {
                    drawRect(
                        color = Color(0x06FFFFFF),
                        topLeft = Offset(0f, y.toFloat()),
                        size = Size(screenSize.width, 2f)
                    )
                }
            }
        }
    }

    private fun calculateCameraOffset(playerPos: Vector2, screenSize: Size, mapWidth: Float, mapHeight: Float): Offset {
        val targetX = playerPos.x - screenSize.width / 2f
        val targetY = playerPos.y - screenSize.height / 2f
        val clampedX = targetX.coerceIn(0f, (mapWidth - screenSize.width).coerceAtLeast(0f))
        val clampedY = targetY.coerceIn(0f, (mapHeight - screenSize.height).coerceAtLeast(0f))
        return Offset(clampedX, clampedY)
    }

    private fun drawGround(scope: DrawScope, chapter: GameChapter, viewOffset: Offset, mapW: Float, mapH: Float) {
        with(scope) {
            val baseColor = when (chapter) {
                GameChapter.CHAPTER_1 -> Color(0xFF0F151B)
                GameChapter.CHAPTER_2 -> Color(0xFF0B140D)
                GameChapter.CHAPTER_3 -> Color(0xFF13081E)
            }
            drawRect(color = baseColor, topLeft = -viewOffset, size = Size(mapW, mapH))

            // Road in Chapter 1
            if (chapter == GameChapter.CHAPTER_1) {
                val roadTop = 100f - viewOffset.y
                val roadHeight = 380f
                drawRect(
                    color = Color(0xFF1E232A),
                    topLeft = Offset(-viewOffset.x, roadTop),
                    size = Size(mapW, roadHeight)
                )
                // Road dashes
                for (x in 0..mapW.toInt() step 80) {
                    drawRect(
                        color = Color(0x66FFFF88),
                        topLeft = Offset(x - viewOffset.x, roadTop + roadHeight / 2f - 3f),
                        size = Size(40f, 6f)
                    )
                }
            }

            // Chapter 3 Glitch Tiles
            if (chapter == GameChapter.CHAPTER_3) {
                for (gx in 0..mapW.toInt() step 200) {
                    for (gy in 0..mapH.toInt() step 200) {
                        drawRect(
                            color = Color(0x0A9C27B0),
                            topLeft = Offset(gx - viewOffset.x, gy - viewOffset.y),
                            size = Size(90f, 90f)
                        )
                    }
                }
            }
        }
    }

    private fun drawObstacle(scope: DrawScope, obs: Obstacle, viewOffset: Offset, chapter: GameChapter) {
        with(scope) {
            val screenRect = Rect(
                obs.bounds.left - viewOffset.x,
                obs.bounds.top - viewOffset.y,
                obs.bounds.right - viewOffset.x,
                obs.bounds.bottom - viewOffset.y
            )

            when (obs.type) {
                ObstacleType.TREE -> {
                    // Tree shadow
                    drawOval(
                        color = Color(0x66000000),
                        topLeft = Offset(screenRect.left - 10f, screenRect.bottom - 20f),
                        size = Size(screenRect.width + 20f, 30f)
                    )
                    // Pine foliage
                    val pineColor = if (chapter == GameChapter.CHAPTER_3) Color(0xFF381442) else obs.color
                    drawRect(color = pineColor, topLeft = screenRect.topLeft, size = screenRect.size)
                    // Inner pine detail
                    drawCircle(
                        color = pineColor.copy(alpha = 0.8f),
                        radius = screenRect.width * 0.45f,
                        center = screenRect.center
                    )
                }
                ObstacleType.VEHICLE -> {
                    // Car shadow
                    drawRect(
                        color = Color(0x88000000),
                        topLeft = screenRect.topLeft + Offset(6f, 10f),
                        size = screenRect.size
                    )
                    // Car body (Dark Sedan)
                    drawRect(
                        color = obs.color,
                        topLeft = screenRect.topLeft,
                        size = screenRect.size
                    )
                    // Windshield
                    drawRect(
                        color = Color(0xFF4FC3F7).copy(alpha = 0.5f),
                        topLeft = Offset(screenRect.left + 25f, screenRect.top + 15f),
                        size = Size(screenRect.width - 50f, 25f)
                    )
                    // Headlights glow markers
                    drawCircle(
                        color = Color(0xFFFFF59D),
                        radius = 8f,
                        center = Offset(screenRect.right - 8f, screenRect.top + 20f)
                    )
                    drawCircle(
                        color = Color(0xFFFFF59D),
                        radius = 8f,
                        center = Offset(screenRect.right - 8f, screenRect.bottom - 20f)
                    )
                }
                ObstacleType.FENCE -> {
                    drawRect(color = obs.color, topLeft = screenRect.topLeft, size = screenRect.size)
                    // Posts
                    for (fx in screenRect.left.toInt()..screenRect.right.toInt() step 30) {
                        drawRect(
                            color = Color(0xFF9E9E9E),
                            topLeft = Offset(fx.toFloat(), screenRect.top - 4f),
                            size = Size(5f, screenRect.height + 8f)
                        )
                    }
                }
                ObstacleType.BOULDER -> {
                    drawOval(color = obs.color, topLeft = screenRect.topLeft, size = screenRect.size)
                }
                else -> {
                    drawRect(color = obs.color, topLeft = screenRect.topLeft, size = screenRect.size)
                }
            }
        }
    }

    private fun drawInteractable(scope: DrawScope, item: Interactable, viewOffset: Offset, engine: GameEngine) {
        with(scope) {
            val screenPos = Offset(item.pos.x - viewOffset.x, item.pos.y - viewOffset.y)
            val isNearby = engine.currentInteractable?.id == item.id
            val pulse = (sin(System.currentTimeMillis() * 0.006) * 4f + 12f).toFloat()

            // Glowing indicator
            val auraColor = if (isNearby) Color(0xFFFFEB3B) else Color(0xFF80DEEA)
            drawCircle(
                color = auraColor.copy(alpha = if (isNearby) 0.6f else 0.35f),
                radius = pulse + 6f,
                center = screenPos
            )
            drawCircle(
                color = auraColor,
                radius = 6f,
                center = screenPos
            )

            // Outer interaction ring when player is close
            if (isNearby) {
                drawCircle(
                    color = Color.Yellow,
                    radius = item.radius,
                    center = screenPos,
                    style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
                )
            }
        }
    }

    private fun drawMonster(scope: DrawScope, m: Monster, viewOffset: Offset, textMeasurer: TextMeasurer) {
        with(scope) {
            val screenPos = Offset(m.pos.x - viewOffset.x, m.pos.y - viewOffset.y)

            if (m.state == MonsterState.DEAD) {
                // Dissolving shadow puddle
                val dissolveAlpha = (1f - m.animTimer / 1.5f).coerceIn(0f, 1f)
                drawOval(
                    color = Color(0xFF2A1B3D).copy(alpha = dissolveAlpha * 0.7f),
                    topLeft = screenPos - Offset(24f, 12f),
                    size = Size(48f, 24f)
                )
                return
            }

            // Stunned vibration
            val stunJitter = if (m.stunTimer > 0f) (kotlin.random.Random.nextFloat() * 6f - 3f) else 0f
            val drawPos = screenPos + Offset(stunJitter, 0f)

            when (m.category) {
                MonsterCategory.MIST_WEEPER -> {
                    // Translucent crying specter
                    drawCircle(
                        color = Color(0xAA455A64),
                        radius = 18f,
                        center = drawPos
                    )
                    // Weeping white eyes
                    drawCircle(
                        color = Color.White,
                        radius = 3.5f,
                        center = drawPos + Offset(4f * cos(m.facingAngle) - 4f, 4f * sin(m.facingAngle) - 4f)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 3.5f,
                        center = drawPos + Offset(4f * cos(m.facingAngle) + 4f, 4f * sin(m.facingAngle) - 4f)
                    )
                }

                MonsterCategory.BRAMBLE_CRAWLER -> {
                    // Thorny scuttler
                    drawCircle(color = Color(0xFF2E1C14), radius = 16f, center = drawPos)
                    for (i in 0 until 6) {
                        val legAngle = i * (PI.toFloat() / 3f) + m.animTimer * 6f
                        drawLine(
                            color = Color(0xFF5D4037),
                            start = drawPos,
                            end = drawPos + Offset(cos(legAngle) * 26f, sin(legAngle) * 26f),
                            strokeWidth = 3f
                        )
                    }
                    drawCircle(color = Color(0xFFFF5252), radius = 2.5f, center = drawPos)
                }

                MonsterCategory.GORGE_ECHO_BOSS -> {
                    // Giant shadowy chimera with purple aura
                    drawCircle(
                        color = Color(0x66AB47BC),
                        radius = 42f + sin(m.animTimer * 4f) * 6f,
                        center = drawPos
                    )
                    drawCircle(color = Color(0xFF1F0D29), radius = 32f, center = drawPos)
                    // Red multi-eyes
                    drawCircle(color = Color(0xFFFF1744), radius = 6f, center = drawPos + Offset(-10f, -8f))
                    drawCircle(color = Color(0xFFFF1744), radius = 6f, center = drawPos + Offset(10f, -8f))
                    drawCircle(color = Color(0xFFFFC400), radius = 4f, center = drawPos + Offset(0f, 6f))
                }

                MonsterCategory.TIMBER_LURKER -> {
                    // Tall bark demon
                    drawRect(
                        color = Color(0xFF3E2723),
                        topLeft = drawPos - Offset(16f, 28f),
                        size = Size(32f, 56f)
                    )
                    drawCircle(color = Color(0xFFFFF176), radius = 3f, center = drawPos - Offset(5f, 16f))
                    drawCircle(color = Color(0xFFFFF176), radius = 3f, center = drawPos - Offset(-5f, 16f))
                }

                MonsterCategory.LANTERN_GHOUL -> {
                    // Floating skull with lantern jaw
                    drawCircle(color = Color(0xFFECEFF1), radius = 20f, center = drawPos)
                    drawCircle(color = Color(0xFF00E676), radius = 10f, center = drawPos + Offset(0f, 12f))
                    drawCircle(color = Color.Black, radius = 4f, center = drawPos - Offset(6f, 4f))
                    drawCircle(color = Color.Black, radius = 4f, center = drawPos - Offset(-6f, 4f))
                }

                MonsterCategory.CORRUPTED_WOODCUTTER_BOSS -> {
                    // Hulking phantom lumberjack
                    drawRect(
                        color = Color(0xFF261C14),
                        topLeft = drawPos - Offset(26f, 38f),
                        size = Size(52f, 76f)
                    )
                    // Cursed Axe in hand
                    val axePos = drawPos + Offset(cos(m.facingAngle) * 36f, sin(m.facingAngle) * 36f)
                    drawLine(color = Color(0xFF8D6E63), start = drawPos, end = axePos, strokeWidth = 6f)
                    drawRect(color = Color(0xFFFF5722), topLeft = axePos - Offset(8f, 14f), size = Size(24f, 28f))
                    // Glowing eyes under hood
                    drawCircle(color = Color(0xFFFF3D00), radius = 4f, center = drawPos - Offset(8f, 20f))
                    drawCircle(color = Color(0xFFFF3D00), radius = 4f, center = drawPos - Offset(-8f, 20f))
                }

                MonsterCategory.STATIC_PHANTOM -> {
                    // Glitching static silhouette
                    val glitchOffset = Offset(
                        (kotlin.random.Random.nextFloat() * 8f - 4f),
                        (kotlin.random.Random.nextFloat() * 8f - 4f)
                    )
                    drawRect(
                        color = Color(0xFF00E5FF).copy(alpha = 0.7f),
                        topLeft = drawPos - Offset(16f, 26f) + glitchOffset,
                        size = Size(32f, 52f)
                    )
                    drawRect(
                        color = Color.White,
                        topLeft = drawPos - Offset(12f, 22f),
                        size = Size(24f, 44f)
                    )
                }

                MonsterCategory.GUILT_WEAVER -> {
                    // Eldritch obelisk with giant red crying eye
                    drawRect(
                        color = Color(0xFF311B92),
                        topLeft = drawPos - Offset(18f, 40f),
                        size = Size(36f, 80f)
                    )
                    drawCircle(color = Color(0xFFE91E63), radius = 14f, center = drawPos - Offset(0f, 15f))
                    drawCircle(color = Color.Black, radius = 6f, center = drawPos - Offset(0f, 15f))
                }

                MonsterCategory.THE_VOID_BOSS -> {
                    // Final Boss: swirling vortex of memory & shadow
                    val voidPulse = sin(m.animTimer * 5f) * 10f
                    drawCircle(
                        color = Color(0x889C27B0),
                        radius = 52f + voidPulse,
                        center = drawPos
                    )
                    drawCircle(color = Color(0xFF0A0014), radius = 42f, center = drawPos)
                    // Swirling rings
                    drawCircle(
                        color = Color(0xFFE040FB),
                        radius = 35f,
                        center = drawPos,
                        style = Stroke(width = 4f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), m.animTimer * 40f))
                    )
                    // The weeping white face in the center
                    drawCircle(color = Color(0xDDFFFFFF), radius = 16f, center = drawPos)
                    drawCircle(color = Color.Black, radius = 3.5f, center = drawPos - Offset(5f, 3f))
                    drawCircle(color = Color.Black, radius = 3.5f, center = drawPos - Offset(-5f, 3f))
                }
            }

            // Health Bar above monster
            if (m.hp < m.maxHp || m.isBoss) {
                val barW = if (m.isBoss) 80f else 36f
                val barH = if (m.isBoss) 7f else 4f
                val barTop = drawPos.y - (if (m.isBoss) 55f else 35f)
                val barLeft = drawPos.x - barW / 2f
                val hpRatio = (m.hp / m.maxHp).coerceIn(0f, 1f)

                // Background
                drawRect(color = Color(0xAA000000), topLeft = Offset(barLeft - 1f, barTop - 1f), size = Size(barW + 2f, barH + 2f))
                // Fill
                drawRect(
                    color = if (m.isBoss) Color(0xFFFF1744) else Color(0xFFFFCA28),
                    topLeft = Offset(barLeft, barTop),
                    size = Size(barW * hpRatio, barH)
                )

                if (m.isBoss) {
                    drawText(
                        textMeasurer = textMeasurer,
                        text = m.name.uppercase(),
                        topLeft = Offset(barLeft, barTop - 16f),
                        style = TextStyle.Default.copy(
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
            }
        }
    }

    private fun drawPlayer(scope: DrawScope, engine: GameEngine, viewOffset: Offset) {
        with(scope) {
            val screenPos = Offset(engine.playerPos.x - viewOffset.x, engine.playerPos.y - viewOffset.y)

            // Player shadow
            drawOval(
                color = Color(0x88000000),
                topLeft = screenPos - Offset(16f, 6f),
                size = Size(32f, 16f)
            )

            // Player sprite (Arthur Vance: trench coat, flashlight/weapon)
            val invulnerableFlicker = engine.invincibilityTimer > 0f && (engine.invincibilityTimer * 20f).toInt() % 2 == 0
            val bodyAlpha = if (invulnerableFlicker) 0.35f else 1.0f

            // Trench coat body
            drawRect(
                color = Color(0xFF37474F).copy(alpha = bodyAlpha),
                topLeft = screenPos - Offset(12f, 20f),
                size = Size(24f, 36f)
            )
            // Head & collar
            drawCircle(
                color = Color(0xFFFFCC80).copy(alpha = bodyAlpha),
                radius = 9f,
                center = screenPos - Offset(0f, 22f)
            )
            // Dark detective fedora/hair
            drawRect(
                color = Color(0xFF263238).copy(alpha = bodyAlpha),
                topLeft = screenPos - Offset(12f, 33f),
                size = Size(24f, 8f)
            )

            // Facing direction indicator / weapon in hand
            val facingRad = engine.playerFacing.angleRad()
            val handPos = screenPos + Offset(cos(facingRad) * 16f, sin(facingRad) * 16f)

            if (engine.equippedWeapon == WeaponType.BASEBALL_BAT) {
                // Draw baseball bat
                val batAngle = if (engine.isSwingingBat) facingRad + (1f - engine.attackAnimTimer / 0.25f) * 2f - 1f else facingRad - 0.4f
                val batTip = screenPos + Offset(cos(batAngle) * 36f, sin(batAngle) * 36f)
                drawLine(
                    color = Color(0xFFD7CCC8),
                    start = handPos,
                    end = batTip,
                    strokeWidth = 5f
                )
                if (engine.isSwingingBat) {
                    // Bat swing motion blur arc
                    drawArc(
                        color = Color.White.copy(alpha = 0.5f),
                        startAngle = (facingRad - 0.8f) * 180f / PI.toFloat(),
                        sweepAngle = 100f,
                        useCenter = false,
                        topLeft = screenPos - Offset(38f, 38f),
                        size = Size(76f, 76f),
                        style = Stroke(width = 8f)
                    )
                }
            } else {
                // Draw Revolver
                val gunTip = screenPos + Offset(cos(facingRad) * 28f, sin(facingRad) * 28f)
                drawLine(
                    color = Color(0xFF212121),
                    start = handPos,
                    end = gunTip,
                    strokeWidth = 4f
                )
            }
        }
    }

    private fun drawDarknessFog(scope: DrawScope, engine: GameEngine, viewOffset: Offset, screenSize: Size) {
        with(scope) {
            val playerScreenPos = Offset(engine.playerPos.x - viewOffset.x, engine.playerPos.y - viewOffset.y)

            // Flashlight cone if enabled
            if (engine.flashlightOn) {
                val facingAngle = engine.playerFacing.angleRad()
                val beamLength = 260f
                val beamSpread = 0.45f

                val path = Path().apply {
                    moveTo(playerScreenPos.x, playerScreenPos.y)
                    val p1 = playerScreenPos + Offset(cos(facingAngle - beamSpread) * beamLength, sin(facingAngle - beamSpread) * beamLength)
                    val p2 = playerScreenPos + Offset(cos(facingAngle) * (beamLength + 30f), sin(facingAngle) * (beamLength + 30f))
                    val p3 = playerScreenPos + Offset(cos(facingAngle + beamSpread) * beamLength, sin(facingAngle + beamSpread) * beamLength)
                    lineTo(p1.x, p1.y)
                    lineTo(p2.x, p2.y)
                    lineTo(p3.x, p3.y)
                    close()
                }

                drawPath(
                    path = path,
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x55FFF9C4), Color(0x22FFF59D), Color.Transparent),
                        center = playerScreenPos,
                        radius = beamLength
                    )
                )
            }

            // Car headlights cone in Chapter 1
            if (engine.currentChapter == GameChapter.CHAPTER_1) {
                val carScreenHeadlights = Offset(475f - viewOffset.x, 290f - viewOffset.y)
                val headlightPath = Path().apply {
                    moveTo(carScreenHeadlights.x, carScreenHeadlights.y - 20f)
                    lineTo(carScreenHeadlights.x + 380f, carScreenHeadlights.y - 90f)
                    lineTo(carScreenHeadlights.x + 400f, carScreenHeadlights.y)
                    lineTo(carScreenHeadlights.x + 380f, carScreenHeadlights.y + 90f)
                    lineTo(carScreenHeadlights.x, carScreenHeadlights.y + 20f)
                    close()
                }
                drawPath(
                    path = headlightPath,
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color(0x88FFF9C4), Color(0x33FFF59D), Color.Transparent),
                        startX = carScreenHeadlights.x,
                        endX = carScreenHeadlights.x + 400f
                    )
                )
            }

            // Radial ambient player light halo
            val haloRadius = if (engine.flashlightOn) 130f else 65f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Transparent, Color(0x88000000), Color(0xEE05070A)),
                    center = playerScreenPos,
                    radius = haloRadius
                ),
                radius = haloRadius,
                center = playerScreenPos
            )

            // Outer dark vignette overlay
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Transparent, Color(0x33000000), Color(0xD9040608)),
                    center = playerScreenPos,
                    radius = screenSize.width * 0.75f
                ),
                size = screenSize
            )
        }
    }
}
