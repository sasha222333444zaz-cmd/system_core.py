package com.example.ui.menu

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.GameChapter

@Composable
fun ChapterSelectDialog(
    highestUnlockedChapter: Int,
    onSelectChapter: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xE605080E))
                .padding(16.dp)
                .testTag("chapter_select_dialog"),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .background(Color(0xFF0F151F), RoundedCornerShape(12.dp))
                    .border(2.dp, Color(0xFF90CAF9), RoundedCornerShape(12.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ВИБІР РОЗДІЛУ",
                        color = Color(0xFFFFD54F),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_chapter_select")) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Закрити", tint = Color.White)
                    }
                }

                Text(
                    text = "Кожен розділ — 20–30+ хвилин глибокого дослідження, психологічної історії та унікальних боїв.",
                    color = Color(0xFFB0BEC5),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )

                // Chapter Cards in Row for Landscape
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    listOf(
                        Triple(1, GameChapter.CHAPTER_1, "Поїздка та гірські околиці. Пошук револьвера й бити, бос ущелини."),
                        Triple(2, GameChapter.CHAPTER_2, "Лабіринт глибокого лісу. Генератор із 3 запобіжників, бос лісопилки."),
                        Triple(3, GameChapter.CHAPTER_3, "Сюрреалістичне спотворення. Розколота порожнеча, фінальний бос і 3 фінали.")
                    ).forEach { (num, chapter, desc) ->
                        val isUnlocked = num <= highestUnlockedChapter
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .height(160.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(enabled = isUnlocked) { onSelectChapter(num) }
                                .testTag("chapter_card_$num"),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUnlocked) Color(0xFF1B2433) else Color(0xFF10141B)
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.5.dp,
                                if (isUnlocked) Color(0xFF64B5F6) else Color(0x33FFFFFF)
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "РОЗД. $num",
                                        color = if (isUnlocked) Color(0xFFFFD54F) else Color.Gray,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = chapter.title.substringAfter(": "),
                                        color = if (isUnlocked) Color.White else Color.Gray,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        maxLines = 2
                                    )
                                    Text(
                                        text = desc,
                                        color = if (isUnlocked) Color(0xFFB0BEC5) else Color.DarkGray,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Text(
                                    text = if (isUnlocked) "ГРАТИ" else "ЗАБЛОКОВАНО",
                                    color = if (isUnlocked) Color(0xFF81C784) else Color(0xFFE57373),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
