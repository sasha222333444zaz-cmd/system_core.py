package com.example.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.GameEngine
import com.example.model.GameChapter
import com.example.model.WeaponType

@Composable
fun HUDOverlay(
    engine: GameEngine,
    onOpenJournal: () -> Unit,
    modifier: Modifier = Modifier
) {
    val objectiveText = when (engine.currentChapter) {
        GameChapter.CHAPTER_1 -> {
            when {
                !engine.storyFlags.contains("REVOLVER_FOUND") -> "ЗАВДАННЯ: Знайти зброю в бардачку"
                !engine.storyFlags.contains("BAT_FOUND") -> "ЗАВДАННЯ: Знайти биту в багажнику"
                !engine.storyFlags.contains("ROAD_GATE_UNLOCKED") -> "ЗАВДАННЯ: Оглянути зламане огородження"
                else -> "ЗАВДАННЯ: Спуститися в ущелину по Лео"
            }
        }
        GameChapter.CHAPTER_2 -> {
            if (engine.storyFlags.contains("SAWMILL_POWERED")) {
                "ЗАВДАННЯ: Зустріти примару в цеху лісопилки"
            } else {
                val fuses = engine.inventory.count { it.id.startsWith("fuse_") }
                "ЗАВДАННЯ: Зібрати 3 запобіжники ($fuses/3) для брами"
            }
        }
        GameChapter.CHAPTER_3 -> {
            "ЗАВДАННЯ: Пройти розколоту порожнечу й зустріти правду"
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("hud_overlay"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left Column: Health and Sanity Bars
        Row(
            modifier = Modifier
                .background(Color(0xCC000000), RoundedCornerShape(8.dp))
                .border(1.5.dp, Color(0x66FFFFFF), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Health Bar
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = "Здоров'я",
                    tint = Color(0xFFFF1744),
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Box(
                    modifier = Modifier
                        .width(90.dp)
                        .height(7.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF37474F))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth((engine.playerHp / engine.maxPlayerHp).coerceIn(0f, 1f))
                            .background(Color(0xFFFF1744))
                    )
                }
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "${engine.playerHp.toInt()}",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            // Sanity Bar
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Visibility,
                    contentDescription = "Розсудок",
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Box(
                    modifier = Modifier
                        .width(90.dp)
                        .height(7.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF37474F))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth((engine.playerSanity / engine.maxPlayerSanity).coerceIn(0f, 1f))
                            .background(Color(0xFF00E5FF))
                    )
                }
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "${engine.playerSanity.toInt()}%",
                    color = Color(0xFF00E5FF),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Center: Objective Badge
        Box(
            modifier = Modifier
                .background(Color(0xCC000000), RoundedCornerShape(6.dp))
                .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(6.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(
                text = objectiveText,
                color = Color(0xFFFFD54F),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold
            )
        }

        // Right: Journal Button
        FilledTonalButton(
            onClick = onOpenJournal,
            modifier = Modifier
                .height(36.dp)
                .testTag("journal_menu_button"),
            colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = Color(0xCC1A237E),
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF64B5F6)),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Icon(
                imageVector = Icons.Default.MenuBook,
                contentDescription = "Журнал",
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = "ЖУРНАЛ",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
