package com.example.ui.controls

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.GameEngine
import com.example.model.Vector2
import com.example.model.WeaponType
import kotlin.math.min
import kotlin.math.sqrt

@Composable
fun VirtualJoystick(
    modifier: Modifier = Modifier,
    onMove: (Vector2) -> Unit
) {
    val joystickRadius = 56.dp
    val thumbRadius = 24.dp

    var thumbOffset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .size(joystickRadius * 2)
            .testTag("virtual_joystick")
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val dragVector = offset - center
                        val maxDist = size.width / 2f - 20f
                        val dist = dragVector.getDistance()
                        val clamped = if (dist > maxDist) dragVector * (maxDist / dist) else dragVector
                        thumbOffset = clamped
                        onMove(Vector2(clamped.x / maxDist, clamped.y / maxDist))
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val newOffset = thumbOffset + dragAmount
                        val maxDist = size.width / 2f - 20f
                        val dist = newOffset.getDistance()
                        val clamped = if (dist > maxDist) newOffset * (maxDist / dist) else newOffset
                        thumbOffset = clamped
                        onMove(Vector2(clamped.x / maxDist, clamped.y / maxDist))
                    },
                    onDragEnd = {
                        thumbOffset = Offset.Zero
                        onMove(Vector2.Zero)
                    },
                    onDragCancel = {
                        thumbOffset = Offset.Zero
                        onMove(Vector2.Zero)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        // Outer Base Ring
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color(0x33FFFFFF),
                radius = size.width / 2f,
                style = Stroke(width = 3.dp.toPx())
            )
            drawCircle(
                color = Color(0x22000000),
                radius = size.width / 2f
            )
            // Center crosshair dots
            drawCircle(color = Color(0x55FFFFFF), radius = 3.dp.toPx())
        }

        // Draggable Thumb Knob
        Box(
            modifier = Modifier
                .offset { IntOffset(thumbOffset.x.toInt(), thumbOffset.y.toInt()) }
                .size(thumbRadius * 2)
                .shadow(6.dp, CircleShape)
                .clip(CircleShape)
                .background(Color(0xDDFFFFFF))
                .border(2.dp, Color(0xFF90CAF9), CircleShape)
        )
    }
}

@Composable
fun ActionControls(
    engine: GameEngine,
    modifier: Modifier = Modifier
) {
    val nearbyItem = engine.currentInteractable

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Contextual Interaction Button when near an object / NPC
        AnimatedVisibility(
            visible = nearbyItem != null && !engine.isIntroCarCutscene,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Button(
                onClick = { engine.onInteract() },
                modifier = Modifier
                    .testTag("interact_button")
                    .padding(bottom = 6.dp)
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD54F)),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White),
                elevation = ButtonDefaults.buttonElevation(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = "Взаємодія",
                    tint = Color.Black
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = nearbyItem?.prompt ?: "ВЗАЄМОДІЯ",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Utility Buttons Row: Flashlight & Reload
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Flashlight Toggle
            FilledTonalIconButton(
                onClick = { engine.onToggleFlashlight() },
                modifier = Modifier
                    .size(46.dp)
                    .testTag("flashlight_button"),
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = if (engine.flashlightOn) Color(0xFFFFEB3B).copy(alpha = 0.85f) else Color(0x66263238),
                    contentColor = if (engine.flashlightOn) Color.Black else Color.White
                )
            ) {
                Icon(
                    imageVector = if (engine.flashlightOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                    contentDescription = "Ліхтар"
                )
            }

            // Reload Revolver Button
            if (engine.equippedWeapon == WeaponType.REVOLVER) {
                FilledTonalIconButton(
                    onClick = { engine.onReloadRevolver() },
                    modifier = Modifier
                        .size(46.dp)
                        .testTag("reload_button"),
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = Color(0x88455A64),
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Перезарядка"
                    )
                }
            }

            // Quick Weapon Switch
            FilledTonalIconButton(
                onClick = { engine.onToggleWeapon() },
                modifier = Modifier
                    .size(46.dp)
                    .testTag("switch_weapon_button"),
                colors = IconButtonDefaults.filledTonalIconButtonColors(
                    containerColor = Color(0xAA37474F),
                    contentColor = Color(0xFFFFCA28)
                )
            ) {
                Icon(
                    imageVector = if (engine.equippedWeapon == WeaponType.BASEBALL_BAT) Icons.Default.SportsBaseball else Icons.Default.CrisisAlert,
                    contentDescription = "Змінити зброю"
                )
            }
        }

        // Primary Combat Buttons: Melee & Ranged
        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            // Melee Bat Button
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .shadow(8.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Color(0xFF8D6E63))
                    .border(3.dp, if (engine.equippedWeapon == WeaponType.BASEBALL_BAT) Color(0xFFFFD54F) else Color.White, CircleShape)
                    .clickable {
                        engine.equippedWeapon = WeaponType.BASEBALL_BAT
                        engine.onMeleeSwing()
                    }
                    .testTag("melee_bat_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SportsBaseball,
                        contentDescription = "Удар битою",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "БИТА",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Ranged Revolver Button
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .shadow(10.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Color(0xFFC62828))
                    .border(3.dp, if (engine.equippedWeapon == WeaponType.REVOLVER) Color(0xFFFFD54F) else Color.White, CircleShape)
                    .clickable {
                        engine.equippedWeapon = WeaponType.REVOLVER
                        engine.onFireRevolver()
                    }
                    .testTag("fire_revolver_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CrisisAlert,
                        contentDescription = "Постріл з револьвера",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = "${engine.revolverAmmoClip}/${engine.revolverReserveAmmo}",
                        color = Color(0xFFFFEB3B),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
