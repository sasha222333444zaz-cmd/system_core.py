package com.example.ui.dialogue

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.GameEngine
import com.example.model.DialogueChoice
import com.example.model.DialogueNode

@Composable
fun DialogueOverlay(
    engine: GameEngine,
    node: DialogueNode,
    modifier: Modifier = Modifier
) {
    val displayedText = node.text.take(engine.typewriterCharCount)

    // Bouncing indicator animation for advance prompt
    val infiniteTransition = rememberInfiniteTransition(label = "dialogue_arrow")
    val arrowOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "arrow_bounce"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dialogue_overlay")
            .padding(12.dp)
            .clickable { engine.onAdvanceDialogue() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black, RoundedCornerShape(8.dp))
                .border(3.dp, Color.White, RoundedCornerShape(8.dp))
                .padding(14.dp)
        ) {
            // Speaker Name Banner
            Text(
                text = "* ${node.speaker.uppercase()}",
                color = Color(0xFFFFEB3B),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Character Portrait Frame
                PortraitFrame(
                    portraitId = node.portrait,
                    modifier = Modifier.size(76.dp)
                )

                // Typewriter Text Body
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 72.dp)
                ) {
                    Text(
                        text = displayedText,
                        color = Color.White,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Medium
                    )

                    // Bouncing '▼' indicator when text complete and no choices
                    if (engine.isDialogueComplete && node.choices.isEmpty()) {
                        Text(
                            text = "▼",
                            color = Color(0xFFFF5252),
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .offset(y = arrowOffset.dp)
                        )
                    }
                }
            }

            // Interactive Choices (if text complete)
            if (engine.isDialogueComplete && node.choices.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    node.choices.forEachIndexed { index, choice ->
                        DialogueChoiceRow(
                            choice = choice,
                            onSelect = { engine.onSelectDialogueChoice(choice) },
                            testTag = "dialogue_choice_$index"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DialogueChoiceRow(
    choice: DialogueChoice,
    onSelect: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .border(1.5.dp, Color(0xFF64B5F6), RoundedCornerShape(4.dp))
            .background(Color(0xFF0D1B2A))
            .clickable { onSelect() }
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "♥",
            color = Color(0xFFFF1744),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = choice.text,
            color = Color(0xFFE0E0E0),
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun PortraitFrame(
    portraitId: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .border(2.dp, Color(0xFF78909C), RoundedCornerShape(4.dp))
            .background(Color(0xFF101720), RoundedCornerShape(4.dp))
            .padding(4.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            when {
                portraitId.startsWith("father") -> {
                    // Trench coat father portrait
                    // Hair & Hat
                    drawRect(color = Color(0xFF263238), topLeft = Offset(w * 0.15f, h * 0.1f), size = Size(w * 0.7f, h * 0.25f))
                    // Face
                    drawRect(color = Color(0xFFFFCC80), topLeft = Offset(w * 0.25f, h * 0.32f), size = Size(w * 0.5f, h * 0.42f))
                    // Stubble
                    drawRect(color = Color(0xFF8D6E63), topLeft = Offset(w * 0.25f, h * 0.6f), size = Size(w * 0.5f, h * 0.14f))
                    // Eyes
                    val eyeY = h * 0.45f
                    if (portraitId.contains("shock")) {
                        drawCircle(color = Color.White, radius = 5f, center = Offset(w * 0.38f, eyeY))
                        drawCircle(color = Color.White, radius = 5f, center = Offset(w * 0.62f, eyeY))
                        drawCircle(color = Color.Black, radius = 2f, center = Offset(w * 0.38f, eyeY))
                        drawCircle(color = Color.Black, radius = 2f, center = Offset(w * 0.62f, eyeY))
                    } else {
                        drawLine(color = Color.Black, start = Offset(w * 0.34f, eyeY), end = Offset(w * 0.44f, eyeY), strokeWidth = 3f)
                        drawLine(color = Color.Black, start = Offset(w * 0.56f, eyeY), end = Offset(w * 0.66f, eyeY), strokeWidth = 3f)
                    }
                }

                portraitId.startsWith("leo") -> {
                    // Little boy Leo
                    // Blonde hair
                    drawCircle(color = Color(0xFFFFEE58), radius = w * 0.38f, center = Offset(w * 0.5f, h * 0.45f))
                    // Face
                    drawCircle(color = Color(0xFFFFE0B2), radius = w * 0.3f, center = Offset(w * 0.5f, h * 0.52f))
                    // Big eyes
                    val eyeY = h * 0.5f
                    drawCircle(color = Color(0xFF1E88E5), radius = 4f, center = Offset(w * 0.4f, eyeY))
                    drawCircle(color = Color(0xFF1E88E5), radius = 4f, center = Offset(w * 0.6f, eyeY))
                    if (portraitId.contains("smile")) {
                        // Smile
                        drawArc(color = Color(0xFFD81B60), startAngle = 0f, sweepAngle = 180f, useCenter = false, topLeft = Offset(w * 0.42f, h * 0.62f), size = Size(w * 0.16f, h * 0.1f))
                    }
                }

                portraitId.startsWith("woodcutter") -> {
                    // Hooded woodcutter with red eyes
                    drawCircle(color = Color(0xFF3E2723), radius = w * 0.4f, center = Offset(w * 0.5f, h * 0.5f))
                    drawCircle(color = Color(0xFFFF3D00), radius = 5f, center = Offset(w * 0.38f, h * 0.48f))
                    drawCircle(color = Color(0xFFFF3D00), radius = 5f, center = Offset(w * 0.62f, h * 0.48f))
                }

                portraitId.startsWith("void") -> {
                    // The Void
                    drawRect(color = Color(0xFF12001F))
                    drawCircle(color = Color.White, radius = w * 0.32f, center = Offset(w * 0.5f, h * 0.5f))
                    drawCircle(color = Color.Black, radius = 5f, center = Offset(w * 0.4f, h * 0.45f))
                    drawCircle(color = Color.Black, radius = 5f, center = Offset(w * 0.6f, h * 0.45f))
                    // Tear trails
                    drawLine(color = Color.Black, start = Offset(w * 0.4f, h * 0.48f), end = Offset(w * 0.4f, h * 0.75f), strokeWidth = 3f)
                    drawLine(color = Color.Black, start = Offset(w * 0.6f, h * 0.48f), end = Offset(w * 0.6f, h * 0.75f), strokeWidth = 3f)
                }

                portraitId.startsWith("radio") -> {
                    // Radio grill
                    drawRect(color = Color(0xFF37474F))
                    for (i in 1..4) {
                        drawLine(color = Color(0xFFFFD54F), start = Offset(w * 0.2f, h * (0.2f * i)), end = Offset(w * 0.8f, h * (0.2f * i)), strokeWidth = 3f)
                    }
                }

                else -> {
                    // Neutral system / note
                    drawRect(color = Color(0xFF263238))
                    drawRect(color = Color(0xFFECEFF1), topLeft = Offset(w * 0.25f, h * 0.2f), size = Size(w * 0.5f, h * 0.6f))
                }
            }
        }
    }
}
