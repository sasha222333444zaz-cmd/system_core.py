package com.example.ui.menu

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.SoundSystem
import kotlin.math.sin

@Composable
fun MainMenuScreen(
    soundSystem: SoundSystem,
    hasSave: Boolean,
    onContinueGame: () -> Unit,
    onNewGame: () -> Unit,
    onOpenChapterSelect: () -> Unit,
    onOpenJournal: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showSettings by remember { mutableStateOf(false) }

    // Pulsing title glow
    val infiniteTransition = rememberInfiniteTransition(label = "title_glow")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF070B10))
            .testTag("main_menu_screen")
    ) {
        // Atmospheric Animated Background Canvas (Headlights cutting fog)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Night sky & mountain gradient
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF030508), Color(0xFF0C131D), Color(0xFF182230))
                )
            )

            // Distant mountain silhouette
            val p1 = Offset(0f, h * 0.45f)
            val p2 = Offset(w * 0.35f, h * 0.38f)
            val p3 = Offset(w * 0.7f, h * 0.42f)
            val p4 = Offset(w, h * 0.4f)
            val mountainPath = androidx.compose.ui.graphics.Path().apply {
                moveTo(p1.x, p1.y)
                lineTo(p2.x, p2.y)
                lineTo(p3.x, p3.y)
                lineTo(p4.x, p4.y)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(mountainPath, color = Color(0xFF070D14))

            // Road surface
            drawRect(color = Color(0xFF101620), topLeft = Offset(0f, h * 0.65f), size = androidx.compose.ui.geometry.Size(w, h * 0.35f))

            // Twin headlights beams piercing the fog
            val leftLightCenter = Offset(w * 0.38f, h * 0.68f)
            val rightLightCenter = Offset(w * 0.62f, h * 0.68f)

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xDDFFF9C4), Color(0x44FFF59D), Color.Transparent),
                    center = leftLightCenter,
                    radius = w * 0.35f
                ),
                center = leftLightCenter,
                radius = w * 0.35f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xDDFFF9C4), Color(0x44FFF59D), Color.Transparent),
                    center = rightLightCenter,
                    radius = w * 0.35f
                ),
                center = rightLightCenter,
                radius = w * 0.35f
            )

            // Red tail lights of the mystery sedan
            drawCircle(color = Color(0xFFFF1744), radius = 6f, center = Offset(w * 0.44f, h * 0.68f))
            drawCircle(color = Color(0xFFFF1744), radius = 6f, center = Offset(w * 0.56f, h * 0.68f))
        }

        // Main Menu Content Overlay (Landscape Optimized)
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Column: Cinematic Title & Lore Teaser
            Column(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "HOLLOW DESCENT",
                    color = Color(0xFFFFD54F).copy(alpha = glowAlpha),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "Психологічна темна RPG",
                    color = Color(0xFF90CAF9),
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "Спуск батька в шепітливий туман хребта Блеквуд, щоб повернути зниклого сина.",
                    color = Color(0xFFCFD8DC),
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth(0.85f)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Розділи I–III • Дві зброї • Ретро-звук",
                    color = Color(0xFF78909C),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Right Column: Ergonomic Menu Buttons
            Column(
                modifier = Modifier
                    .weight(0.9f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.End
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(0.95f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (hasSave) {
                        Button(
                            onClick = onContinueGame,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("menu_continue_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0)),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF64B5F6))
                        ) {
                            Text(
                                text = "ПРОДОВЖИТИ ПОДОРОЖ",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Button(
                        onClick = onNewGame,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("menu_new_game_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF37474F)),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF90A4AE))
                    ) {
                        Text(
                            text = "НОВА ГРА (РОЗДІЛ I)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Button(
                        onClick = onOpenChapterSelect,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("menu_chapter_select_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF263238)),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF546E7A))
                    ) {
                        Text(
                            text = "ВИБІР РОЗДІЛУ (1 - 3)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Button(
                        onClick = onOpenJournal,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("menu_lore_journal_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2630)),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF37474F))
                    ) {
                        Text(
                            text = "ЖУРНАЛ І ЗБРОЯ",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    FilledTonalButton(
                        onClick = { showSettings = !showSettings },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .testTag("menu_settings_button"),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF101720)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "Налаштування", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "SETTINGS", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Quick Settings Dialog
        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = {
                    Text("НАЛАШТУВАННЯ ЗВУКУ Й ВІБРАЦІЇ", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color(0xFFFFD54F))
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Звукові ефекти й звуки мовлення", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                            Switch(
                                checked = soundSystem.isSoundEnabled,
                                onCheckedChange = { soundSystem.isSoundEnabled = it }
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Вібровідгук і віддача", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                            Switch(
                                checked = soundSystem.isHapticsEnabled,
                                onCheckedChange = { soundSystem.isHapticsEnabled = it }
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { showSettings = false }) {
                        Text("ГОТОВО", fontFamily = FontFamily.Monospace)
                    }
                },
                containerColor = Color(0xFF0F151F)
            )
        }
    }
}
