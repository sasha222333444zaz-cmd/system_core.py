package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.audio.SoundSystem
import com.example.data.SaveManager
import com.example.engine.GameEngine
import com.example.ui.GameScreen
import com.example.ui.menu.ChapterSelectDialog
import com.example.ui.menu.InventoryJournalDialog
import com.example.ui.menu.MainMenuScreen
import com.example.ui.theme.MyApplicationTheme

enum class AppScreen {
    MAIN_MENU,
    GAME
}

class MainActivity : ComponentActivity() {

    private lateinit var soundSystem: SoundSystem
    private lateinit var saveManager: SaveManager
    private lateinit var gameEngine: GameEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        soundSystem = SoundSystem(applicationContext)
        saveManager = SaveManager(applicationContext)
        gameEngine = GameEngine(soundSystem, saveManager)

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    var currentScreen by remember { mutableStateOf(AppScreen.MAIN_MENU) }
                    var showChapterSelect by remember { mutableStateOf(false) }
                    var showMenuJournal by remember { mutableStateOf(false) }

                    when (currentScreen) {
                        AppScreen.MAIN_MENU -> {
                            MainMenuScreen(
                                soundSystem = soundSystem,
                                hasSave = saveManager.getHighestChapterUnlocked() > 1 || saveManager.loadGame().foundNotes.isNotEmpty(),
                                onContinueGame = {
                                    val saved = saveManager.loadGame()
                                    gameEngine.loadInitialChapter(saved.chapter)
                                    currentScreen = AppScreen.GAME
                                },
                                onNewGame = {
                                    gameEngine.loadInitialChapter(1)
                                    currentScreen = AppScreen.GAME
                                },
                                onOpenChapterSelect = { showChapterSelect = true },
                                onOpenJournal = { showMenuJournal = true }
                            )

                            if (showChapterSelect) {
                                ChapterSelectDialog(
                                    highestUnlockedChapter = saveManager.getHighestChapterUnlocked(),
                                    onSelectChapter = { ch ->
                                        showChapterSelect = false
                                        gameEngine.loadInitialChapter(ch)
                                        currentScreen = AppScreen.GAME
                                    },
                                    onDismiss = { showChapterSelect = false }
                                )
                            }

                            if (showMenuJournal) {
                                InventoryJournalDialog(
                                    engine = gameEngine,
                                    onDismiss = { showMenuJournal = false }
                                )
                            }
                        }

                        AppScreen.GAME -> {
                            GameScreen(
                                engine = gameEngine,
                                onReturnToMainMenu = {
                                    currentScreen = AppScreen.MAIN_MENU
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
