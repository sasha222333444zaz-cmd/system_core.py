# Hollow Descent — українська версія

Психологічна темна 2D RPG для Android (Kotlin + Jetpack Compose).
Увесь текст гри (меню, діалоги, HUD, журнал, предмети, фінали) перекладено українською.

## Як зібрати APK

1. Встановіть [Android Studio](https://developer.android.com/studio).
2. File → Open → оберіть папку проєкту й дочекайтеся синхронізації Gradle.
3. Підключіть телефон (режим розробника + налагодження USB) або запустіть емулятор.
4. Натисніть Run ▶ — гра встановиться на пристрій.
5. Щоб отримати файл APK: Build → Build Bundle(s) / APK(s) → Build APK(s).

Якщо Android Studio скаржиться на `signingConfig = signingConfigs.getByName("debugConfig")`
у `app/build.gradle.kts`, видаліть цей рядок.

Гра працює в горизонтальній орієнтації.

## Збірка APK без комп'ютера (через GitHub)

1. Створіть безкоштовний акаунт на github.com і новий репозиторій.
2. Завантажте в нього вміст цього проєкту (разом із папкою `.github`).
3. Вкладка Actions → Build APK → Run workflow.
4. Коли збірка завершиться, у запуску внизу буде архів `hollow-descent-apk` — усередині файл .apk.
